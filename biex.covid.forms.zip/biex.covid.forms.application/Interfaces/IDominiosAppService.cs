﻿using biex.covid.forms.domain.entidades;
using System.Collections.Generic;

namespace biex.covid.forms.application.Interfaces
{
    public interface IDominiosAppService
    {       

    }

}

