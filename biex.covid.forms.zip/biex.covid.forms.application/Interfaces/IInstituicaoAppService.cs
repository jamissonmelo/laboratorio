﻿using biex.covid.forms.domain.entidades;

namespace biex.covid.forms.application.Interfaces
{
    public interface IInstituicaoAppService : IAppServiceBase<Instituicao> { }
}
