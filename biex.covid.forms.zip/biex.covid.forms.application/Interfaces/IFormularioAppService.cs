﻿using biex.covid.forms.domain.entidades;
using System.Collections.Generic;

namespace biex.covid.forms.application.Interfaces
{
    public interface IFormularioAppService : IAppServiceBase<Formulario> {
        IEnumerable<GrupoPaciente> GetGrupos();
        void DesassociarEstudo(Formulario obj);
        void AssociarEstudo(Formulario obj);

        Formulario GetByCPF(string CPF);
        Formulario GetByCodigoControle(int CodigoControle);
        IEnumerable<FormularioList> GetHomeData();

    }

}
