﻿using System.Collections.Generic;
using biex.covid.forms.application.Interfaces;
using biex.covid.forms.domain.entidades;
using biex.covid.forms.domain.interfaces.services;

namespace biex.covid.forms.application
{
    public class FormularioAppService : AppServiceBase<Formulario>, IFormularioAppService
    {
        private readonly IFormularioService _svc;
        public FormularioAppService(IFormularioService Svc)
            : base(Svc)
        {
            _svc = Svc;
        }

        public void AssociarEstudo(Formulario obj)
        {
            _svc.AssociarEstudo(obj);
        }

        public void DesassociarEstudo(Formulario obj)
        {
            _svc.DesassociarEstudo(obj);
        }

        public Formulario GetByCodigoControle(int CodigoControle)
        {
            return _svc.GetByCodigoControle(CodigoControle);
        }

        public Formulario GetByCPF(string CPF)
        {
            return _svc.GetByCPF(CPF);
        }

        public IEnumerable<GrupoPaciente> GetGrupos()
        {
            return _svc.GetGrupos();
        }

        public IEnumerable<FormularioList> GetHomeData()
        {
            return _svc.GetHomeData();
        }

        

    }



}
