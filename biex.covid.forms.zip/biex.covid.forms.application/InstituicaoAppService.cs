﻿using biex.covid.forms.application.Interfaces;
using biex.covid.forms.domain.entidades;
using biex.covid.forms.domain.interfaces.services;

namespace biex.covid.forms.application
{
    public class InstituicaoAppService : AppServiceBase<Instituicao>, IInstituicaoAppService
    {
        private readonly IInstituicaoService _svc;
        public InstituicaoAppService(IInstituicaoService Svc)
            : base(Svc)
        {
            _svc = Svc;
        }
    }



}
