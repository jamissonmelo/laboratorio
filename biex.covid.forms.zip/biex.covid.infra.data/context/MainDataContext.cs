﻿using biex.covid.infra.data.config;
using System;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace biex.covid.infra.data.context
{

    public class MainDataContext : DbContext
    {
        public MainDataContext() : base("DefaultConnectionstring")
        {
            //TODO : Veriry why we need this horrible hack to ensure Entities SQL dll is loaded.
            //source: http://robsneuron.blogspot.in/2013/11/entity-framework-upgrade-to-6.html
            var ensureDLLIsCopied = System.Data.Entity.SqlServer.SqlProviderServices.Instance;

            //    context.Database.Log = Console.Write; 
            this.Database.Log = Console.Write;
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();

            modelBuilder.Properties<string>()
                .Configure(p => p.HasColumnType("varchar"));

            modelBuilder.Properties<string>()
                .Configure(p => p.IsOptional());

            modelBuilder.Properties<string>()
                .Configure(p => p.HasMaxLength(100));

            modelBuilder.Properties<string>().Configure(p => p.IsUnicode(false));

            modelBuilder.Configurations.Add(new GrupoPacienteConfiguration());
            modelBuilder.Configurations.Add(new FormularioConfiguration());
            modelBuilder.Configurations.Add(new InstituicaoConfiguration());
            //modelBuilder.Configurations.Add(new RacaConfiguration());
            //modelBuilder.Configurations.Add(new SindromeRespiratoriaConfiguration());


        }


    }

}
