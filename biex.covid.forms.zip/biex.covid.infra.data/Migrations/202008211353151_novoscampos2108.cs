﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class novoscampos2108 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "IL_6_d3", c => c.Decimal(precision: 18, scale: 2));
            AddColumn("dbo.tb_formulario", "IL1_beta_d3", c => c.Decimal(precision: 18, scale: 2));
            AddColumn("dbo.tb_formulario", "IL8_d3", c => c.Decimal(precision: 18, scale: 2));
            AddColumn("dbo.tb_formulario", "TNF_alfa_d3", c => c.Decimal(precision: 18, scale: 2));
            AddColumn("dbo.tb_formulario", "MCP_1_d3", c => c.Decimal(precision: 18, scale: 2));
            AddColumn("dbo.tb_formulario", "IFN_d3", c => c.Decimal(precision: 18, scale: 2));
            AddColumn("dbo.tb_formulario", "IL_6_d8", c => c.Decimal(precision: 18, scale: 2));
            AddColumn("dbo.tb_formulario", "IL1_beta_d8", c => c.Decimal(precision: 18, scale: 2));
            AddColumn("dbo.tb_formulario", "IL8_d8", c => c.Decimal(precision: 18, scale: 2));
            AddColumn("dbo.tb_formulario", "TNF_alfa_d8", c => c.Decimal(precision: 18, scale: 2));
            AddColumn("dbo.tb_formulario", "MCP_1_d8", c => c.Decimal(precision: 18, scale: 2));
            AddColumn("dbo.tb_formulario", "IFN_d8", c => c.Decimal(precision: 18, scale: 2));
        }
        
        public override void Down()
        {
            DropColumn("dbo.tb_formulario", "IFN_d8");
            DropColumn("dbo.tb_formulario", "MCP_1_d8");
            DropColumn("dbo.tb_formulario", "TNF_alfa_d8");
            DropColumn("dbo.tb_formulario", "IL8_d8");
            DropColumn("dbo.tb_formulario", "IL1_beta_d8");
            DropColumn("dbo.tb_formulario", "IL_6_d8");
            DropColumn("dbo.tb_formulario", "IFN_d3");
            DropColumn("dbo.tb_formulario", "MCP_1_d3");
            DropColumn("dbo.tb_formulario", "TNF_alfa_d3");
            DropColumn("dbo.tb_formulario", "IL8_d3");
            DropColumn("dbo.tb_formulario", "IL1_beta_d3");
            DropColumn("dbo.tb_formulario", "IL_6_d3");
        }
    }
}
