﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class flag_d1 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "d1", c => c.Boolean(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.tb_formulario", "d1");
        }
    }
}
