﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class campos_obrigatorios : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.tb_formulario", "carga_viral_d1", c => c.Int());
            AlterColumn("dbo.tb_formulario", "hg_d1", c => c.Int());
            AlterColumn("dbo.tb_formulario", "htc_d1", c => c.Int());
            AlterColumn("dbo.tb_formulario", "leuco_d1", c => c.Int());
            AlterColumn("dbo.tb_formulario", "linfo_d1", c => c.Int());
            AlterColumn("dbo.tb_formulario", "d1_complete", c => c.Int());
            AlterColumn("dbo.tb_formulario", "hg_d1_v2", c => c.Int());
            AlterColumn("dbo.tb_formulario", "htc_d1_v2", c => c.Int());
            AlterColumn("dbo.tb_formulario", "leuco_d1_v2", c => c.Int());
            AlterColumn("dbo.tb_formulario", "linfo_d1_v2", c => c.Int());
            AlterColumn("dbo.tb_formulario", "neutro_d1_v2", c => c.Int());
            AlterColumn("dbo.tb_formulario", "pcr_d1_v2", c => c.Int());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.tb_formulario", "pcr_d1_v2", c => c.Int(nullable: false));
            AlterColumn("dbo.tb_formulario", "neutro_d1_v2", c => c.Int(nullable: false));
            AlterColumn("dbo.tb_formulario", "linfo_d1_v2", c => c.Int(nullable: false));
            AlterColumn("dbo.tb_formulario", "leuco_d1_v2", c => c.Int(nullable: false));
            AlterColumn("dbo.tb_formulario", "htc_d1_v2", c => c.Int(nullable: false));
            AlterColumn("dbo.tb_formulario", "hg_d1_v2", c => c.Int(nullable: false));
            AlterColumn("dbo.tb_formulario", "d1_complete", c => c.Int(nullable: false));
            AlterColumn("dbo.tb_formulario", "linfo_d1", c => c.Int(nullable: false));
            AlterColumn("dbo.tb_formulario", "leuco_d1", c => c.Int(nullable: false));
            AlterColumn("dbo.tb_formulario", "htc_d1", c => c.Int(nullable: false));
            AlterColumn("dbo.tb_formulario", "hg_d1", c => c.Int(nullable: false));
            AlterColumn("dbo.tb_formulario", "carga_viral_d1", c => c.Int(nullable: false));
        }
    }
}
