﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class EsquemadosIDS : DbMigration
    {
        public override void Up()
        {
            DropPrimaryKey("dbo.tb_formulario");
            AlterColumn("dbo.tb_formulario", "id_formulario", c => c.Int(nullable: false));
            AddPrimaryKey("dbo.tb_formulario", "id_formulario");
        }
        
        public override void Down()
        {
            DropPrimaryKey("dbo.tb_formulario");
            AlterColumn("dbo.tb_formulario", "id_formulario", c => c.Int(nullable: false, identity: true));
            AddPrimaryKey("dbo.tb_formulario", "id_formulario");
        }
    }
}
