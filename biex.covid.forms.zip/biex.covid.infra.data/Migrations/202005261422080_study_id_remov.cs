﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class study_id_remov : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.tb_formulario", "study_id");
        }
        
        public override void Down()
        {
            AddColumn("dbo.tb_formulario", "study_id", c => c.Int(nullable: false));
        }
    }
}
