﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class sint_respirat_v2_dias : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "sint_respirat_v2_dias", c => c.String(maxLength: 1000, unicode: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.tb_formulario", "sint_respirat_v2_dias");
        }
    }
}
