﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class defaultcovid : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.tb_formulario", "covid_d1", c => c.Boolean());
            AlterColumn("dbo.tb_formulario", "covid_d1_v2", c => c.Boolean());
        }
        
        public override void Down()
        {
            AlterColumn("dbo.tb_formulario", "covid_d1_v2", c => c.Boolean(nullable: false));
            AlterColumn("dbo.tb_formulario", "covid_d1", c => c.Boolean(nullable: false));
        }
    }
}
