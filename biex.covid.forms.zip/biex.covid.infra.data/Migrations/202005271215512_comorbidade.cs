﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class comorbidade : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.tb_formulario", "comorbidade", c => c.String(maxLength: 1000, unicode: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.tb_formulario", "comorbidade", c => c.String(maxLength: 100, unicode: false));
        }
    }
}
