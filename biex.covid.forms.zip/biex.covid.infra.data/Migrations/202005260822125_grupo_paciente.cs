﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class grupo_paciente : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.tb_formulario", "id_formulario", "dbo.tb_grupopaciente");
            DropIndex("dbo.tb_formulario", new[] { "id_formulario" });
        }
        
        public override void Down()
        {
            CreateIndex("dbo.tb_formulario", "id_formulario");
            AddForeignKey("dbo.tb_formulario", "id_formulario", "dbo.tb_grupopaciente", "id_grupopaciente");
        }
    }
}
