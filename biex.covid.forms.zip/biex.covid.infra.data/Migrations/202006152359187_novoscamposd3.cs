﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class novoscamposd3 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "pacienteretornou_d3", c => c.Boolean());
            AddColumn("dbo.tb_formulario", "dsc_pacienteretornou_d3", c => c.String(maxLength: 100, unicode: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.tb_formulario", "dsc_pacienteretornou_d3");
            DropColumn("dbo.tb_formulario", "pacienteretornou_d3");
        }
    }
}
