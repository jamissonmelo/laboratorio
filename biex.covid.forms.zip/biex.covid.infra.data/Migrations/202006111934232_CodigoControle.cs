﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CodigoControle : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "codigocontrole", c => c.Int());
        }
        
        public override void Down()
        {
            DropColumn("dbo.tb_formulario", "codigocontrole");
        }
    }
}
