﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class NovosCampos11062020 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "data_covid_d1", c => c.DateTime());
            AddColumn("dbo.tb_formulario", "data_covid_d1_v2", c => c.DateTime());
            AddColumn("dbo.tb_formulario", "medicamentotodo", c => c.Boolean());
            AddColumn("dbo.tb_formulario", "diasesqueceu", c => c.Int());
        }
        
        public override void Down()
        {
            DropColumn("dbo.tb_formulario", "diasesqueceu");
            DropColumn("dbo.tb_formulario", "medicamentotodo");
            DropColumn("dbo.tb_formulario", "data_covid_d1_v2");
            DropColumn("dbo.tb_formulario", "data_covid_d1");
        }
    }
}
