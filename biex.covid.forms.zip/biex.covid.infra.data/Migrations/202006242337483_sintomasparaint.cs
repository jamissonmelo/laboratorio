﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class sintomasparaint : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.tb_formulario", "sintomas", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.tb_formulario", "sintomas", c => c.String(maxLength: 100, unicode: false));
        }
    }
}
