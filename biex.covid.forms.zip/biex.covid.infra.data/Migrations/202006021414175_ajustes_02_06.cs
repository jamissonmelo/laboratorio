﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ajustes_02_06 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "tempo_inicio_medicacao_d1", c => c.Int());
            AddColumn("dbo.tb_formulario", "tempo_falta_ar_d1", c => c.Int());
            AddColumn("dbo.tb_formulario", "tempo_ventilacao_nao_invasiva_d7", c => c.Int());
            AddColumn("dbo.tb_formulario", "tempo_intubacao_d7", c => c.Int());
            DropColumn("dbo.tb_formulario", "demografia_complete");
            DropColumn("dbo.tb_formulario", "d1_complete");
            DropColumn("dbo.tb_formulario", "d7_complete");
        }
        
        public override void Down()
        {
            AddColumn("dbo.tb_formulario", "d7_complete", c => c.Int(nullable: false));
            AddColumn("dbo.tb_formulario", "d1_complete", c => c.Int());
            AddColumn("dbo.tb_formulario", "demografia_complete", c => c.Int(nullable: false));
            DropColumn("dbo.tb_formulario", "tempo_intubacao_d7");
            DropColumn("dbo.tb_formulario", "tempo_ventilacao_nao_invasiva_d7");
            DropColumn("dbo.tb_formulario", "tempo_falta_ar_d1");
            DropColumn("dbo.tb_formulario", "tempo_inicio_medicacao_d1");
        }
    }
}
