﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Entidades_p_enums : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.tb_formulario", "id_raca", "dbo.tb_raca");
            DropForeignKey("dbo.tb_formulario", "id_sint_respirat", "dbo.tb_sindromerespiratoria");
            DropForeignKey("dbo.tb_formulario", "id_sint_respirat_v2", "dbo.tb_sindromerespiratoria");
            DropIndex("dbo.tb_formulario", new[] { "id_raca" });
            DropIndex("dbo.tb_formulario", new[] { "id_sint_respirat" });
            DropIndex("dbo.tb_formulario", new[] { "id_sint_respirat_v2" });
            AddColumn("dbo.tb_formulario", "race", c => c.Int(nullable: false));
            AddColumn("dbo.tb_formulario", "sint_respirat", c => c.Int(nullable: false));
            AddColumn("dbo.tb_formulario", "sint_respirat_v2", c => c.Int(nullable: false));
            DropColumn("dbo.tb_formulario", "id_raca");
            DropColumn("dbo.tb_formulario", "id_sexo");
            DropColumn("dbo.tb_formulario", "id_sint_respirat");
            DropColumn("dbo.tb_formulario", "id_sint_respirat_v2");
            DropTable("dbo.tb_raca");
            DropTable("dbo.tb_sindromerespiratoria");
        }
        
        public override void Down()
        {
            CreateTable(
                "dbo.tb_sindromerespiratoria",
                c => new
                    {
                        id_sindromerespiratoria = c.Int(nullable: false),
                        Nome = c.String(maxLength: 100, unicode: false),
                        Descricao = c.String(maxLength: 100, unicode: false),
                    })
                .PrimaryKey(t => t.id_sindromerespiratoria);
            
            CreateTable(
                "dbo.tb_raca",
                c => new
                    {
                        id_raca = c.Int(nullable: false),
                        nom_raca = c.String(nullable: false, maxLength: 200, unicode: false),
                    })
                .PrimaryKey(t => t.id_raca);
            
            AddColumn("dbo.tb_formulario", "id_sint_respirat_v2", c => c.Int());
            AddColumn("dbo.tb_formulario", "id_sint_respirat", c => c.Int());
            AddColumn("dbo.tb_formulario", "id_sexo", c => c.Int(nullable: false));
            AddColumn("dbo.tb_formulario", "id_raca", c => c.Int(nullable: false));
            DropColumn("dbo.tb_formulario", "sint_respirat_v2");
            DropColumn("dbo.tb_formulario", "sint_respirat");
            DropColumn("dbo.tb_formulario", "race");
            CreateIndex("dbo.tb_formulario", "id_sint_respirat_v2");
            CreateIndex("dbo.tb_formulario", "id_sint_respirat");
            CreateIndex("dbo.tb_formulario", "id_raca");
            AddForeignKey("dbo.tb_formulario", "id_sint_respirat_v2", "dbo.tb_sindromerespiratoria", "id_sindromerespiratoria");
            AddForeignKey("dbo.tb_formulario", "id_sint_respirat", "dbo.tb_sindromerespiratoria", "id_sindromerespiratoria");
            AddForeignKey("dbo.tb_formulario", "id_raca", "dbo.tb_raca", "id_raca", cascadeDelete: true);
        }
    }
}
