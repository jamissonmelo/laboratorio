﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AjustecampoPA2 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.tb_formulario", "temperatura_d1", c => c.Decimal(precision: 18, scale: 2));
            AlterColumn("dbo.tb_formulario", "carga_viral_d1", c => c.Decimal(precision: 18, scale: 2));
            AlterColumn("dbo.tb_formulario", "hg_d1", c => c.Decimal(precision: 18, scale: 2));
            AlterColumn("dbo.tb_formulario", "temperatura_d7", c => c.Decimal(precision: 18, scale: 2));
            AlterColumn("dbo.tb_formulario", "carga_viral_d1_v2", c => c.Decimal(precision: 18, scale: 2));
            AlterColumn("dbo.tb_formulario", "hg_d1_v2", c => c.Decimal(precision: 18, scale: 2));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.tb_formulario", "hg_d1_v2", c => c.Int());
            AlterColumn("dbo.tb_formulario", "carga_viral_d1_v2", c => c.String(maxLength: 100, unicode: false));
            AlterColumn("dbo.tb_formulario", "temperatura_d7", c => c.Int());
            AlterColumn("dbo.tb_formulario", "hg_d1", c => c.Int());
            AlterColumn("dbo.tb_formulario", "carga_viral_d1", c => c.Int());
            AlterColumn("dbo.tb_formulario", "temperatura_d1", c => c.Int());
        }
    }
}
