﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class campoD8 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "d8", c => c.Boolean(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.tb_formulario", "d8");
        }
    }
}
