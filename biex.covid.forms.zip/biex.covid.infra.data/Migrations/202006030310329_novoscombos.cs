﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class novoscombos : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "teveoutroseventosadversos", c => c.Boolean());
            AddColumn("dbo.tb_formulario", "tevereacoesadversas", c => c.Boolean());
        }
        
        public override void Down()
        {
            DropColumn("dbo.tb_formulario", "tevereacoesadversas");
            DropColumn("dbo.tb_formulario", "teveoutroseventosadversos");
        }
    }
}
