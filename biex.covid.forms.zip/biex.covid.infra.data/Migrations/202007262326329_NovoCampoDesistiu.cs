﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class NovoCampoDesistiu : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "motivodesistencia_d3", c => c.String(maxLength: 100, unicode: false));
            AddColumn("dbo.tb_formulario", "motivodesistencia_d8", c => c.String(maxLength: 100, unicode: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.tb_formulario", "motivodesistencia_d8");
            DropColumn("dbo.tb_formulario", "motivodesistencia_d3");
        }
    }
}
