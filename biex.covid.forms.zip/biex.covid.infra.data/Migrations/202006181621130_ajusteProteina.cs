﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ajusteProteina : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.tb_formulario", "pcr_d1_v2", c => c.String(maxLength: 100, unicode: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.tb_formulario", "pcr_d1_v2", c => c.Int());
        }
    }
}
