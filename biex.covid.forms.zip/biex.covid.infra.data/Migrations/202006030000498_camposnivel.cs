﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class camposnivel : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "eventosadversosnivel", c => c.String(maxLength: 1000, unicode: false));
            AddColumn("dbo.tb_formulario", "outroseventosadversosnivel", c => c.String(maxLength: 100, unicode: false));
            AddColumn("dbo.tb_formulario", "reacoesadversasnivel", c => c.String(maxLength: 100, unicode: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.tb_formulario", "reacoesadversasnivel");
            DropColumn("dbo.tb_formulario", "outroseventosadversosnivel");
            DropColumn("dbo.tb_formulario", "eventosadversosnivel");
        }
    }
}
