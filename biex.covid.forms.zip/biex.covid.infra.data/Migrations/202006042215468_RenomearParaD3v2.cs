﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class RenomearParaD3v2 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "interna_d1_v2_desc", c => c.String(maxLength: 100, unicode: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.tb_formulario", "interna_d1_v2_desc");
        }
    }
}
