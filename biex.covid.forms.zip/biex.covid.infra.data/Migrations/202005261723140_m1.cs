﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class m1 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "fr_d1", c => c.Int());
            AddColumn("dbo.tb_formulario", "fc_d1", c => c.Int());
            AddColumn("dbo.tb_formulario", "pa_d1", c => c.Int());
            AddColumn("dbo.tb_formulario", "temperatura_d1", c => c.Int());
            AddColumn("dbo.tb_formulario", "pacientevivo", c => c.Boolean());
            AddColumn("dbo.tb_formulario", "fr_d7", c => c.Int());
            AddColumn("dbo.tb_formulario", "fc_d7", c => c.Int());
            AddColumn("dbo.tb_formulario", "pa_d7", c => c.Int());
            AddColumn("dbo.tb_formulario", "temperatura_d7", c => c.Int());
            AddColumn("dbo.tb_formulario", "outrosmedicamentos", c => c.String(maxLength: 100, unicode: false));
            AddColumn("dbo.tb_formulario", "efeitosadversos", c => c.String(maxLength: 1000, unicode: false));
            AlterColumn("dbo.tb_formulario", "sint_respirat", c => c.String(maxLength: 1000, unicode: false));
            AlterColumn("dbo.tb_formulario", "sint_respirat_v2", c => c.String(maxLength: 1000, unicode: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.tb_formulario", "sint_respirat_v2", c => c.String(maxLength: 100, unicode: false));
            AlterColumn("dbo.tb_formulario", "sint_respirat", c => c.String(maxLength: 100, unicode: false));
            DropColumn("dbo.tb_formulario", "efeitosadversos");
            DropColumn("dbo.tb_formulario", "outrosmedicamentos");
            DropColumn("dbo.tb_formulario", "temperatura_d7");
            DropColumn("dbo.tb_formulario", "pa_d7");
            DropColumn("dbo.tb_formulario", "fc_d7");
            DropColumn("dbo.tb_formulario", "fr_d7");
            DropColumn("dbo.tb_formulario", "pacientevivo");
            DropColumn("dbo.tb_formulario", "temperatura_d1");
            DropColumn("dbo.tb_formulario", "pa_d1");
            DropColumn("dbo.tb_formulario", "fc_d1");
            DropColumn("dbo.tb_formulario", "fr_d1");
        }
    }
}
