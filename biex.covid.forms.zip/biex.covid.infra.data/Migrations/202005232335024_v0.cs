﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class v0 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.tb_grupopaciente",
                c => new
                    {
                        id_grupopaciente = c.Int(nullable: false, identity: true),
                        nom_grupopaciente = c.String(nullable: false, maxLength: 10, unicode: false),
                    })
                .PrimaryKey(t => t.id_grupopaciente);
            
            CreateTable(
                "dbo.tb_formulario",
                c => new
                    {
                        id_formulario = c.Int(nullable: false, identity: true),
                        id_instituicao = c.Int(nullable: false),
                        id_usuario = c.String(maxLength: 100, unicode: false),
                        study_id = c.Int(nullable: false),
                        date_enrolled = c.DateTime(nullable: false),
                        patient_document = c.Binary(),
                        patient_document_mime = c.String(maxLength: 100, unicode: false),
                        first_name = c.String(maxLength: 100, unicode: false),
                        last_name = c.String(maxLength: 100, unicode: false),
                        cpf_d1 = c.String(maxLength: 100, unicode: false),
                        telephone_1 = c.String(maxLength: 100, unicode: false),
                        dob = c.DateTime(nullable: false),
                        id_raca = c.Int(nullable: false),
                        sex = c.Int(nullable: false),
                        id_sexo = c.Int(nullable: false),
                        given_birth = c.Boolean(nullable: false),
                        num_children = c.Int(nullable: false),
                        sintomas = c.String(maxLength: 100, unicode: false),
                        height = c.String(maxLength: 100, unicode: false),
                        weight = c.String(maxLength: 100, unicode: false),
                        comments = c.String(maxLength: 100, unicode: false),
                        demografia_complete = c.Int(nullable: false),
                        id_sint_respirat = c.Int(),
                        outros_sint_respir = c.String(maxLength: 100, unicode: false),
                        swab_nasal_d1 = c.Boolean(nullable: false),
                        covid_d1 = c.Boolean(nullable: false),
                        carga_viral_d1 = c.Int(nullable: false),
                        interna_d1 = c.Boolean(nullable: false),
                        mediadores_d1 = c.Boolean(nullable: false),
                        hg_d1 = c.Int(nullable: false),
                        htc_d1 = c.Int(nullable: false),
                        leuco_d1 = c.Int(nullable: false),
                        linfo_d1 = c.Int(nullable: false),
                        plaquet_d1 = c.String(maxLength: 100, unicode: false),
                        pcr_d1 = c.String(maxLength: 100, unicode: false),
                        d1_complete = c.Int(nullable: false),
                        id_sint_respirat_v2 = c.Int(),
                        outros_sint_respir_v2 = c.String(maxLength: 100, unicode: false),
                        swab_nasal_d1_v2 = c.Boolean(nullable: false),
                        covid_d1_v2 = c.Boolean(nullable: false),
                        carga_viral_d1_v2 = c.String(maxLength: 100, unicode: false),
                        interna_d1_v2 = c.Boolean(nullable: false),
                        mediadores_d1_v2 = c.Boolean(nullable: false),
                        hg_d1_v2 = c.Int(nullable: false),
                        htc_d1_v2 = c.Int(nullable: false),
                        leuco_d1_v2 = c.Int(nullable: false),
                        linfo_d1_v2 = c.Int(nullable: false),
                        neutro_d1_v2 = c.Int(nullable: false),
                        plaquet_d1_v2 = c.String(maxLength: 100, unicode: false),
                        pcr_d1_v2 = c.Int(nullable: false),
                        d7_complete = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.id_formulario)
                .ForeignKey("dbo.tb_grupopaciente", t => t.id_formulario)
                .ForeignKey("dbo.tb_instituicao", t => t.id_instituicao, cascadeDelete: true)
                .ForeignKey("dbo.tb_raca", t => t.id_raca, cascadeDelete: true)
                .ForeignKey("dbo.tb_sindromerespiratoria", t => t.id_sint_respirat)
                .ForeignKey("dbo.tb_sindromerespiratoria", t => t.id_sint_respirat_v2)
                .Index(t => t.id_formulario)
                .Index(t => t.id_instituicao)
                .Index(t => t.id_raca)
                .Index(t => t.id_sint_respirat)
                .Index(t => t.id_sint_respirat_v2);
            
            CreateTable(
                "dbo.tb_instituicao",
                c => new
                    {
                        id_instituicao = c.Int(nullable: false, identity: true),
                        Nome = c.String(maxLength: 100, unicode: false),
                    })
                .PrimaryKey(t => t.id_instituicao);
            
            CreateTable(
                "dbo.tb_raca",
                c => new
                    {
                        id_raca = c.Int(nullable: false),
                        nom_raca = c.String(nullable: false, maxLength: 200, unicode: false),
                    })
                .PrimaryKey(t => t.id_raca);
            
            CreateTable(
                "dbo.tb_sindromerespiratoria",
                c => new
                    {
                        id_sindromerespiratoria = c.Int(nullable: false),
                        Nome = c.String(maxLength: 100, unicode: false),
                        Descricao = c.String(maxLength: 100, unicode: false),
                    })
                .PrimaryKey(t => t.id_sindromerespiratoria);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.tb_formulario", "id_sint_respirat_v2", "dbo.tb_sindromerespiratoria");
            DropForeignKey("dbo.tb_formulario", "id_sint_respirat", "dbo.tb_sindromerespiratoria");
            DropForeignKey("dbo.tb_formulario", "id_raca", "dbo.tb_raca");
            DropForeignKey("dbo.tb_formulario", "id_instituicao", "dbo.tb_instituicao");
            DropForeignKey("dbo.tb_formulario", "id_formulario", "dbo.tb_grupopaciente");
            DropIndex("dbo.tb_formulario", new[] { "id_sint_respirat_v2" });
            DropIndex("dbo.tb_formulario", new[] { "id_sint_respirat" });
            DropIndex("dbo.tb_formulario", new[] { "id_raca" });
            DropIndex("dbo.tb_formulario", new[] { "id_instituicao" });
            DropIndex("dbo.tb_formulario", new[] { "id_formulario" });
            DropTable("dbo.tb_sindromerespiratoria");
            DropTable("dbo.tb_raca");
            DropTable("dbo.tb_instituicao");
            DropTable("dbo.tb_formulario");
            DropTable("dbo.tb_grupopaciente");
        }
    }
}
