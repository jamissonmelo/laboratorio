﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class campo1 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "comorbidade", c => c.String(maxLength: 100, unicode: false));
            AlterColumn("dbo.tb_formulario", "race", c => c.String(maxLength: 100, unicode: false));
            AlterColumn("dbo.tb_formulario", "sex", c => c.String(maxLength: 100, unicode: false));
            AlterColumn("dbo.tb_formulario", "height", c => c.Int(nullable: false));
            AlterColumn("dbo.tb_formulario", "weight", c => c.Int(nullable: false));
            AlterColumn("dbo.tb_formulario", "comments", c => c.String(unicode: false));
            AlterColumn("dbo.tb_formulario", "sint_respirat", c => c.String(maxLength: 100, unicode: false));
            AlterColumn("dbo.tb_formulario", "sint_respirat_v2", c => c.String(maxLength: 100, unicode: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.tb_formulario", "sint_respirat_v2", c => c.Int(nullable: false));
            AlterColumn("dbo.tb_formulario", "sint_respirat", c => c.Int(nullable: false));
            AlterColumn("dbo.tb_formulario", "comments", c => c.String(maxLength: 100, unicode: false));
            AlterColumn("dbo.tb_formulario", "weight", c => c.String(maxLength: 100, unicode: false));
            AlterColumn("dbo.tb_formulario", "height", c => c.String(maxLength: 100, unicode: false));
            AlterColumn("dbo.tb_formulario", "sex", c => c.Int(nullable: false));
            AlterColumn("dbo.tb_formulario", "race", c => c.Int(nullable: false));
            DropColumn("dbo.tb_formulario", "comorbidade");
        }
    }
}
