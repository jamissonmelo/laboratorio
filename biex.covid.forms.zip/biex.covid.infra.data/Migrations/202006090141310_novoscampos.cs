﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class novoscampos : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "telephone_2", c => c.String(maxLength: 100, unicode: false));
            AddColumn("dbo.tb_formulario", "escolaridade", c => c.String(maxLength: 100, unicode: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.tb_formulario", "escolaridade");
            DropColumn("dbo.tb_formulario", "telephone_2");
        }
    }
}
