﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class RenomearParaD3 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "d3", c => c.Boolean(nullable: false));
            AddColumn("dbo.tb_formulario", "mediadores_d3", c => c.Boolean(nullable: false));
            AddColumn("dbo.tb_formulario", "hg_d3", c => c.Decimal(precision: 18, scale: 2));
            AddColumn("dbo.tb_formulario", "htc_d3", c => c.Int());
            AddColumn("dbo.tb_formulario", "leuco_d3", c => c.Int());
            AddColumn("dbo.tb_formulario", "linfo_d3", c => c.Int());
            AddColumn("dbo.tb_formulario", "neutro_d3", c => c.Int());
            AddColumn("dbo.tb_formulario", "plaquet_d3", c => c.String(maxLength: 100, unicode: false));
            AddColumn("dbo.tb_formulario", "pcr_d3", c => c.String(maxLength: 100, unicode: false));
            DropColumn("dbo.tb_formulario", "mediadores_d1");
            DropColumn("dbo.tb_formulario", "hg_d1");
            DropColumn("dbo.tb_formulario", "htc_d1");
            DropColumn("dbo.tb_formulario", "leuco_d1");
            DropColumn("dbo.tb_formulario", "linfo_d1");
            DropColumn("dbo.tb_formulario", "neutro_d1");
            DropColumn("dbo.tb_formulario", "plaquet_d1");
            DropColumn("dbo.tb_formulario", "pcr_d1");
        }
        
        public override void Down()
        {
            AddColumn("dbo.tb_formulario", "pcr_d1", c => c.String(maxLength: 100, unicode: false));
            AddColumn("dbo.tb_formulario", "plaquet_d1", c => c.String(maxLength: 100, unicode: false));
            AddColumn("dbo.tb_formulario", "neutro_d1", c => c.Int());
            AddColumn("dbo.tb_formulario", "linfo_d1", c => c.Int());
            AddColumn("dbo.tb_formulario", "leuco_d1", c => c.Int());
            AddColumn("dbo.tb_formulario", "htc_d1", c => c.Int());
            AddColumn("dbo.tb_formulario", "hg_d1", c => c.Decimal(precision: 18, scale: 2));
            AddColumn("dbo.tb_formulario", "mediadores_d1", c => c.Boolean(nullable: false));
            DropColumn("dbo.tb_formulario", "pcr_d3");
            DropColumn("dbo.tb_formulario", "plaquet_d3");
            DropColumn("dbo.tb_formulario", "neutro_d3");
            DropColumn("dbo.tb_formulario", "linfo_d3");
            DropColumn("dbo.tb_formulario", "leuco_d3");
            DropColumn("dbo.tb_formulario", "htc_d3");
            DropColumn("dbo.tb_formulario", "hg_d3");
            DropColumn("dbo.tb_formulario", "mediadores_d3");
            DropColumn("dbo.tb_formulario", "d3");
        }
    }
}
