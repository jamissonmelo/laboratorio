﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AjustecampoPA : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.tb_formulario", "pa_d1", c => c.String(maxLength: 100, unicode: false));
            AlterColumn("dbo.tb_formulario", "pa_d7", c => c.String(maxLength: 100, unicode: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.tb_formulario", "pa_d7", c => c.Int());
            AlterColumn("dbo.tb_formulario", "pa_d1", c => c.Int());
        }
    }
}
