﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Datacoletad3 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "data_da_coleta_d3", c => c.DateTime());
        }
        
        public override void Down()
        {
            DropColumn("dbo.tb_formulario", "data_da_coleta_d3");
        }
    }
}
