﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class novosajustes1406 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "data_swab_nasal_d1", c => c.DateTime());
            AddColumn("dbo.tb_formulario", "id_ct_vacinas_d1", c => c.String(maxLength: 100, unicode: false));
            AddColumn("dbo.tb_formulario", "data_swab_nasal_d1_v2", c => c.DateTime());
            AddColumn("dbo.tb_formulario", "id_ct_vacinas_d8", c => c.String(maxLength: 100, unicode: false));
            DropColumn("dbo.tb_formulario", "swab_nasal_d1");
            DropColumn("dbo.tb_formulario", "swab_nasal_d1_v2");
        }
        
        public override void Down()
        {
            AddColumn("dbo.tb_formulario", "swab_nasal_d1_v2", c => c.Boolean());
            AddColumn("dbo.tb_formulario", "swab_nasal_d1", c => c.Boolean());
            DropColumn("dbo.tb_formulario", "id_ct_vacinas_d8");
            DropColumn("dbo.tb_formulario", "data_swab_nasal_d1_v2");
            DropColumn("dbo.tb_formulario", "id_ct_vacinas_d1");
            DropColumn("dbo.tb_formulario", "data_swab_nasal_d1");
        }
    }
}
