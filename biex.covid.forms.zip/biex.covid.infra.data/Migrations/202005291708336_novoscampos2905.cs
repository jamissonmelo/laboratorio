﻿namespace biex.covid.infra.data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class novoscampos2905 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.tb_formulario", "pct_saturat_spo2", c => c.Int());
            AddColumn("dbo.tb_formulario", "pct_saturat_spo2_v2", c => c.Int());
            AddColumn("dbo.tb_formulario", "eventosadversos", c => c.String(maxLength: 1000, unicode: false));
            AddColumn("dbo.tb_formulario", "outroseventosadversos", c => c.String(maxLength: 100, unicode: false));
            AddColumn("dbo.tb_formulario", "reacoesadversas", c => c.String(maxLength: 100, unicode: false));
            DropColumn("dbo.tb_formulario", "interna_d1");
            DropColumn("dbo.tb_formulario", "efeitosadversos");
        }
        
        public override void Down()
        {
            AddColumn("dbo.tb_formulario", "efeitosadversos", c => c.String(maxLength: 1000, unicode: false));
            AddColumn("dbo.tb_formulario", "interna_d1", c => c.Boolean(nullable: false));
            DropColumn("dbo.tb_formulario", "reacoesadversas");
            DropColumn("dbo.tb_formulario", "outroseventosadversos");
            DropColumn("dbo.tb_formulario", "eventosadversos");
            DropColumn("dbo.tb_formulario", "pct_saturat_spo2_v2");
            DropColumn("dbo.tb_formulario", "pct_saturat_spo2");
        }
    }
}
