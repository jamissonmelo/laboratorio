﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using biex.covid.forms.domain.entidades;
using biex.covid.forms.domain.interfaces.repository;

namespace biex.covid.infra.data.repository
{
    public class FormularioRepository : RepositoryBase<Formulario>, IFormularioRepository
    {
        public IEnumerable<GrupoPaciente> GetGrupos()
        {
            return Db.Set<GrupoPaciente>();
        }

        /// <summary>
        /// Adiciona um novo formulário na sessão DEMOGRAFIA
        /// Ao adicionar o item, associa automaticamente ao próximo ID disponível através da função GetProximoIDDisponivel()
        /// </summary>
        /// <param name="obj">Objeto a ser adicionado</param>
        public new void Add(Formulario obj)
        {

            obj.Id = GetIdLivre();
            Db.Set<Formulario>().Add(obj);
            Db.SaveChanges();
        }

        private int GetIdLivre()
        {
            var id_livre = Db.Database.SqlQuery<int>("select min(gr.id_grupopaciente) Id from tb_grupopaciente gr left outer join tb_formulario fr on fr.id_formulario = gr.id_grupopaciente where fr.id_formulario is null").FirstOrDefault();
            return id_livre;
        }

        private int GetIdLivreDesassociado()
        {
            var id_livredesassociado = Db.Database.SqlQuery<int>("select IsNull(max(id_formulario)+1,10000) id_disponivel from tb_formulario where id_formulario >= 10000").FirstOrDefault();
            return id_livredesassociado;
        }

        public void DesassociarEstudo(Formulario obj)
        {
            Db.Database.ExecuteSqlCommand("update tb_formulario set id_formulario=@id_novo where id_formulario=@id",
                new SqlParameter[] { new SqlParameter("@id_novo", GetIdLivreDesassociado()), new SqlParameter("@id", obj.Id) });

        }

        public void AssociarEstudo(Formulario obj)
        {
            Db.Database.ExecuteSqlCommand("update tb_formulario set id_formulario=@id_novo where id_formulario=@id",
                new SqlParameter[] { new SqlParameter("@id_novo", GetIdLivre()), new SqlParameter("@id", obj.Id) });
        }

        public Formulario GetByCPF(string CPF)
        {
            return Db.Set<Formulario>().Where(x => x.cpf_d1 == CPF).FirstOrDefault();
        }

        public Formulario GetByCodigoControle(int CodigoControle)
        {
            return Db.Set<Formulario>().Where(x => x.codigocontrole == CodigoControle).FirstOrDefault();
        }

        /*
          Id = e.Id,
                                date_enrolled = e.date_enrolled,
                                first_name =    e.first_name,
                                last_name =     e.last_name,
                                cpf_d1 =    e.cpf_d1,
                                grupo = subgrupo != null ? subgrupo.Grupo : string.Empty,
                                d1 =             e.d1,
                                d3 =            e.d3,
                                d8 =            e.d8,
                                covid_d1 = !e.covid_d1.HasValue ? "Em processamento" : e.covid_d1.Value ? "Positivo" : "Negativo",
                                covid_d1_v2 = !e.covid_d1_v2.HasValue ? "Em processamento" : e.covid_d1_v2.Value ? "Positivo" : "Negativo",
                                interna_d1_v2_desc = (e.pacientevivo.HasValue && !e.pacientevivo.Value) ? "Óbito" : e.interna_d1_v2_desc ?? string.Empty,
                                pacientevivo = e.pacientevivo,
                                instituicao = e.Instituicao.Nome,
                                pacienteretornou_d3 = e.pacienteretornou_d3,
                                dsc_pacienteretornou_d3 = e.dsc_pacienteretornou_d3,

 */
        public IEnumerable<FormularioList> GetHomeData()
        {
            var ret = (from e in Db.Set<Formulario>()
                       select new FormularioList
                       {
                           Id = e.Id,
                           id_usuario = e.id_usuario,
                           id_instituicao = e.id_instituicao,
                           date_enrolled = e.date_enrolled,
                           first_name = e.first_name,
                           last_name = e.last_name,
                           cpf_d1 = e.cpf_d1,
                           d1 = e.d1,
                           d3 = e.d3,
                           d8 = e.d8,
                           covid_d1 = e.covid_d1,
                           covid_d1_v2 = e.covid_d1_v2,
                           interna_d1_v2 = e.interna_d1_v2,
                           interna_d1_v2_desc = e.interna_d1_v2_desc,
                           pacientevivo = e.pacientevivo,
                           pacienteretornou_d3 = e.pacienteretornou_d3,
                           dsc_pacienteretornou_d3 = e.dsc_pacienteretornou_d3,
                           instituicao = e.Instituicao.Nome,
                           NomeInstituicao = e.Instituicao.Nome
                       }).ToList();

            return ret;

        }


        public new IEnumerable<Formulario> GetAllOnline()
        {
            //return Db.Set<Formulario>().SqlQuery("select id_formulario Id,id_instituicao,id_usuario,date_enrolled,patient_document_mime,first_name,last_name,cpf_d1,telephone_1,dob,sex,given_birth,num_children,sintomas,height,weight,comments,outros_sint_respir,covid_d1,carga_viral_d1,outros_sint_respir_v2,covid_d1_v2,carga_viral_d1_v2,interna_d1_v2,mediadores_d1_v2,hg_d1_v2,htc_d1_v2,leuco_d1_v2,linfo_d1_v2,neutro_d1_v2,plaquet_d1_v2,pcr_d1_v2,race,sint_respirat,sint_respirat_v2,comorbidade,patient_document_filename,d1,fr_d1,fc_d1,pa_d1,temperatura_d1,pacientevivo,fr_d7,fc_d7,pa_d7,temperatura_d7,outrosmedicamentos,sint_respirat_v2_dias,pct_saturat_spo2,pct_saturat_spo2_v2,eventosadversos,outroseventosadversos,reacoesadversas,tempo_inicio_medicacao_d1,tempo_falta_ar_d1,tempo_ventilacao_nao_invasiva_d7,tempo_intubacao_d7,eventosadversosnivel,outroseventosadversosnivel,reacoesadversasnivel,teveoutroseventosadversos,tevereacoesadversas,d3,mediadores_d3,hg_d3,htc_d3,leuco_d3,linfo_d3,neutro_d3,plaquet_d3,pcr_d3,interna_d1_v2_desc,d8,telephone_2,escolaridade,codigocontrole,data_covid_d1,data_covid_d1_v2,medicamentotodo,diasesqueceu,grupooriginal,data_da_coleta_d3,data_da_coleta_d8,data_swab_nasal_d1,id_ct_vacinas_d1,data_swab_nasal_d1_v2,id_ct_vacinas_d8,pacienteretornou_d3,dsc_pacienteretornou_d3 , cast(null as varbinary)  patient_document from tb_formulario").ToList();

            return
            Db.Set<Formulario>().SqlQuery(@"
                set nocount on                
                declare @q varchar(3000)
                select @q= 'select id_formulario Id, ' + string_agg( c.name, ',') + ' , cast(null as varbinary)  patient_document from tb_formulario'  from sys.columns c 
                inner join sys.tables t on c.object_id=t.object_id
                where t.name = 'tb_formulario' and c.name <> 'patient_document' and c.name <> 'id_formulario'
                execute(@q)").ToList();


        }


    }




}
