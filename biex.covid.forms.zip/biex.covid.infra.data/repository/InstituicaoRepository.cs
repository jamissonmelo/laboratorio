﻿using biex.covid.forms.domain.entidades;
using biex.covid.forms.domain.interfaces.repository;

namespace biex.covid.infra.data.repository
{
    public class InstituicaoRepository : RepositoryBase<Instituicao>, IInstituicaoRepository { }
}
