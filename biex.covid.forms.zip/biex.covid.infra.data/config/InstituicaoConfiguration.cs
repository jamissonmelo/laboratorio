﻿using biex.covid.forms.domain.entidades;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace biex.covid.infra.data.config
{
    internal class InstituicaoConfiguration : EntityTypeConfiguration<Instituicao>
    {
        public InstituicaoConfiguration()
        {
            ToTable("dbo.tb_instituicao");
            HasKey(x => x.Id);
            Property(x => x.Id).HasColumnName("id_instituicao").HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

        }
    }



}
