﻿using biex.covid.forms.domain.entidades;
using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace biex.covid.infra.data.config
{
    internal class GrupoPacienteConfiguration : EntityTypeConfiguration<GrupoPaciente>
    {
        public GrupoPacienteConfiguration()
        {
            ToTable("dbo.tb_grupopaciente");
            HasKey(x => x.Id);

            Property(x => x.Id).HasColumnName("id_grupopaciente").HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            Property(x => x.Grupo).HasColumnName("nom_grupopaciente").HasMaxLength(10).IsRequired();
        }
    }


}
