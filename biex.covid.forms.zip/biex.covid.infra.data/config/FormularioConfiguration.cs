﻿using biex.covid.forms.domain.entidades;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace biex.covid.infra.data.config
{
    internal class FormularioConfiguration : EntityTypeConfiguration<Formulario>
    {
        public FormularioConfiguration()
        {
            ToTable("dbo.tb_formulario");
            HasKey(x => x.Id);

            Property(x => x.Id).HasColumnName("id_formulario").HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            Property(x => x.comments).HasMaxLength(8000).HasColumnType("varchar(max)").IsOptional();


            // HasRequired(filho => filho.race).WithMany(pai => pai.Formularios).HasForeignKey(k => k.id_raca);


            // HasRequired(filho => filho.Grupo).WithRequiredDependent(pai => pai.Formulario);


            HasRequired(filho => filho.Instituicao).WithMany(pai => pai.Formularios).HasForeignKey(k => k.id_instituicao);

            Property(x => x.eventosadversos).HasMaxLength(1000).IsOptional();
            Property(x => x.sint_respirat_v2).HasMaxLength(1000).IsOptional();
            Property(x => x.sint_respirat).HasMaxLength(1000);

            Property(x => x.comorbidade).HasMaxLength(1000).IsOptional();

            Property(x => x.sint_respirat_v2_dias).HasMaxLength(1000).IsOptional();


            Property(x => x.eventosadversosnivel).HasMaxLength(1000).IsOptional();

            Property(x => x.carga_viral_d1).HasPrecision(18, 4);
            Property(x => x.carga_viral_d1_v2).HasPrecision(18, 4);



        }
    }
}
