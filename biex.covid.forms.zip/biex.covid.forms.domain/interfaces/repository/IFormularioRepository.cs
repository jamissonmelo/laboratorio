﻿using biex.covid.forms.domain.entidades;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace biex.covid.forms.domain.interfaces.repository
{
    public interface IFormularioRepository : IRepositoryBase<Formulario>
    {

        IEnumerable<GrupoPaciente> GetGrupos();
        void DesassociarEstudo(Formulario obj);
        void AssociarEstudo(Formulario obj);

        Formulario GetByCPF(string CPF);
        Formulario GetByCodigoControle(int CodigoControle);

        IEnumerable<FormularioList> GetHomeData();


    }

}
