﻿using biex.covid.forms.domain.entidades;

namespace biex.covid.forms.domain.interfaces.repository
{
    public interface IInstituicaoRepository : IRepositoryBase<Instituicao> { }

}
