﻿using biex.covid.forms.domain.entidades;


namespace biex.covid.forms.domain.interfaces.services
{
    public interface IInstituicaoService : IServiceBase<Instituicao> { }
}
