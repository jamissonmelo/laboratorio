﻿using biex.covid.forms.domain.entidades;
using System.Collections.Generic;

namespace biex.covid.forms.domain.interfaces.services
{
    public interface IFormularioService : IServiceBase<Formulario> {

        IEnumerable<GrupoPaciente> GetGrupos();
        void DesassociarEstudo(Formulario obj);
        void AssociarEstudo(Formulario obj);

        Formulario GetByCPF(string CPF);
        Formulario GetByCodigoControle(int CodigoControle);
        IEnumerable<FormularioList> GetHomeData();
    }

}
