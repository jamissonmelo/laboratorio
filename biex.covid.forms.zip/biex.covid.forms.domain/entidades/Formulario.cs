﻿using System;

namespace biex.covid.forms.domain.entidades
{
    public class Formulario
    {

        public int Id { get; set; }

        public string grupooriginal { get; set; }

        public int? codigocontrole { get; set; }

        public virtual Instituicao Instituicao { get; set; }
        public int id_instituicao { get; set; }
        public string id_usuario { get; set; }

        public bool d1 { get; set; }
        public bool d3 { get; set; }

        public bool d8 { get; set; }
        #region Demografia

        public DateTime date_enrolled { get; set; }
        public byte[] patient_document { get; set; }
        public string patient_document_mime { get; set; }
        public string patient_document_filename { get; set; }


        public string first_name { get; set; }
        public string last_name { get; set; }
        public string cpf_d1 { get; set; }
        public string telephone_1 { get; set; }
        public string telephone_2 { get; set; }
        public DateTime dob { get; set; }
        public string race { get; set; }

        public string escolaridade { get; set; }


        public string comorbidade { get; set; }
        public string sex { get; set; }

        public bool given_birth { get; set; }
        public int num_children { get; set; }
        public int sintomas { get; set; }
        public int height { get; set; }
        public int weight { get; set; }
        public string comments { get; set; }


        #endregion

        #region D1

        public string sint_respirat { get; set; }
        public string outros_sint_respir { get; set; }

        public int? fr_d1 { get; set; }
        public int? fc_d1 { get; set; }
        public string pa_d1 { get; set; }
        public decimal? temperatura_d1 { get; set; }

        public DateTime? data_swab_nasal_d1 { get; set; }
        public bool? covid_d1 { get; set; }

        public DateTime? data_covid_d1 { get; set; }

        public decimal? carga_viral_d1 { get; set; }


        public int? pct_saturat_spo2 { get; set; }

        //Tempo do início da doença ao início da medicação
        public int? tempo_inicio_medicacao_d1 { get; set; }
        //Tempo desde o início da doença até a falta de ar
        public int? tempo_falta_ar_d1 { get; set; }

        public string id_ct_vacinas_d1 { get; set; }


        #endregion

        #region D3
        public bool? pacienteretornou_d3 { get; set; }
        public string dsc_pacienteretornou_d3 { get; set; }

        public bool mediadores_d3 { get; set; }
        public decimal? hg_d3 { get; set; }
        public int? htc_d3 { get; set; }
        public int? leuco_d3 { get; set; }
        public int? linfo_d3 { get; set; }
        public int? neutro_d3 { get; set; }
        public string plaquet_d3 { get; set; }
        public string pcr_d3 { get; set; }

        public DateTime? data_da_coleta_d3 { get; set; }

        public string motivodesistencia_d3 { get; set; }


        //campos novos 21/08
        public decimal? IL_6_d3 { get; set; }
        public decimal? IL1_beta_d3 { get; set; }
        public decimal? IL8_d3 { get; set; }
        public decimal? TNF_alfa_d3 { get; set; }
        public decimal? MCP_1_d3 { get; set; }
        public decimal? IFN_d3 { get; set; }


        #endregion

        #region D8

        public bool? pacientevivo { get; set; }



        public string sint_respirat_v2 { get; set; }
        public string sint_respirat_v2_dias { get; set; }

        public string outros_sint_respir_v2 { get; set; }


        public int? fr_d7 { get; set; }
        public int? fc_d7 { get; set; }
        public string pa_d7 { get; set; }
        public decimal? temperatura_d7 { get; set; }


        public DateTime? data_swab_nasal_d1_v2 { get; set; }
        public bool? covid_d1_v2 { get; set; }
        public decimal? carga_viral_d1_v2 { get; set; }

        public DateTime? data_covid_d1_v2 { get; set; }

        public int? pct_saturat_spo2_v2 { get; set; }

        public bool interna_d1_v2 { get; set; }

        public string interna_d1_v2_desc { get; set; }//o paciente internou? Se sim.... se não...

        public bool mediadores_d1_v2 { get; set; }//foi realizada coleta..

        public string outrosmedicamentos { get; set; }

        public decimal? hg_d1_v2 { get; set; }
        public int? htc_d1_v2 { get; set; }
        public int? leuco_d1_v2 { get; set; }
        public int? linfo_d1_v2 { get; set; }
        public int? neutro_d1_v2 { get; set; }
        public string plaquet_d1_v2 { get; set; }
        public string pcr_d1_v2 { get; set; }

        public string eventosadversos { get; set; }

        public string eventosadversosnivel { get; set; }

        public bool? teveoutroseventosadversos { get; set; }

        public string outroseventosadversos { get; set; }

        public string outroseventosadversosnivel { get; set; }

        public bool? tevereacoesadversas { get; set; }

        public string reacoesadversas { get; set; }

        public string reacoesadversasnivel { get; set; }

        //Tempo desde o início da doença até oxigenioterapia/Ventilação Não invasiva
        public int? tempo_ventilacao_nao_invasiva_d7 { get; set; }
        //Tempo desde o início da doença falência respiratória aguda e intubação traqueal e ventilação invasiva
        public int? tempo_intubacao_d7 { get; set; }

        public bool? medicamentotodo { get; set; }

        public int? diasesqueceu { get; set; }


        public DateTime? data_da_coleta_d8 { get; set; }


        public string id_ct_vacinas_d8 { get; set; }

        public string motivodesistencia_d8 { get; set; }





        //campos novos 21/08
        public decimal? IL_6_d8 { get; set; }
        public decimal? IL1_beta_d8 { get; set; }
        public decimal? IL8_d8 { get; set; }
        public decimal? TNF_alfa_d8 { get; set; }
        public decimal? MCP_1_d8 { get; set; }
        public decimal? IFN_d8 { get; set; }

        #endregion


    }
}
