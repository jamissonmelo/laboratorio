﻿using System.Collections.Generic;

namespace biex.covid.forms.domain.entidades
{
    public class Instituicao
    {
        public override string ToString()
        {
            return $"{this.Id}-{this.Nome}";
        }
        public int Id { get; set; }
        public string Nome { get; set; }
        public virtual ICollection<Formulario> Formularios { get; set; }
    }


}
