﻿namespace biex.covid.forms.domain.entidades
{
    public class GrupoPaciente
    {
        public int Id { get; set; }
        public string Grupo { get; set; }

        

    }


}
