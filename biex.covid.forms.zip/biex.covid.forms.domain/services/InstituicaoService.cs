﻿using biex.covid.forms.domain.entidades;
using biex.covid.forms.domain.interfaces.repository;
using biex.covid.forms.domain.interfaces.services;

namespace biex.covid.forms.domain.services
{

    public class InstituicaoService : ServiceBase<Instituicao>, IInstituicaoService
    {
        private readonly IInstituicaoRepository _Repo;
        public InstituicaoService(IInstituicaoRepository Repo)
            : base(Repo)
        {
            _Repo = Repo;
        }

    }

}
