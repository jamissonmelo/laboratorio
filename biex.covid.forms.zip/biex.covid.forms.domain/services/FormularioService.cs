﻿using System.Collections.Generic;
using biex.covid.forms.domain.entidades;
using biex.covid.forms.domain.interfaces.repository;
using biex.covid.forms.domain.interfaces.services;

namespace biex.covid.forms.domain.services
{
    public class FormularioService : ServiceBase<Formulario>, IFormularioService
    {
        private readonly IFormularioRepository _Repo;
        public FormularioService(IFormularioRepository Repo)
            : base(Repo)
        {
            _Repo = Repo;
        }

        public void AssociarEstudo(Formulario obj)
        {
            _Repo.AssociarEstudo(obj);
        }

        public void DesassociarEstudo(Formulario obj)
        {
            _Repo.DesassociarEstudo(obj);
        }

        public Formulario GetByCodigoControle(int CodigoControle)
        {
            return _Repo.GetByCodigoControle(CodigoControle);
        }

        public Formulario GetByCPF(string CPF)
        {
            return _Repo.GetByCPF(CPF);
        }

        public IEnumerable<GrupoPaciente> GetGrupos()
        {
            return _Repo.GetGrupos();
        }

        public IEnumerable<FormularioList> GetHomeData()
        {
            return _Repo.GetHomeData();
        }
    }

}
