[assembly: WebActivatorEx.PreApplicationStartMethod(typeof(biex.covid.forms.web.App_Start.NinjectWebCommon), "Start")]
[assembly: WebActivatorEx.ApplicationShutdownMethodAttribute(typeof(biex.covid.forms.web.App_Start.NinjectWebCommon), "Stop")]

namespace biex.covid.forms.web.App_Start
{
    using System;
    using System.Web;
    using biex.covid.forms.application;
    using biex.covid.forms.application.Interfaces;
    using biex.covid.forms.domain.interfaces.repository;
    using biex.covid.forms.domain.interfaces.services;
    using biex.covid.forms.domain.services;
    using biex.covid.infra.data.repository;
    using Microsoft.Web.Infrastructure.DynamicModuleHelper;

    using Ninject;
    using Ninject.Web.Common;
    using Ninject.Web.Common.WebHost;

    public static class NinjectWebCommon
    {
        private static readonly Bootstrapper bootstrapper = new Bootstrapper();

        /// <summary>
        /// Starts the application.
        /// </summary>
        public static void Start()
        {
            DynamicModuleUtility.RegisterModule(typeof(OnePerRequestHttpModule));
            DynamicModuleUtility.RegisterModule(typeof(NinjectHttpModule));
            bootstrapper.Initialize(CreateKernel);
        }

        /// <summary>
        /// Stops the application.
        /// </summary>
        public static void Stop()
        {
            bootstrapper.ShutDown();
        }

        /// <summary>
        /// Creates the kernel that will manage your application.
        /// </summary>
        /// <returns>The created kernel.</returns>
        private static IKernel CreateKernel()
        {
            var kernel = new StandardKernel();
            try
            {
                kernel.Bind<Func<IKernel>>().ToMethod(ctx => () => new Bootstrapper().Kernel);
                kernel.Bind<IHttpModule>().To<HttpApplicationInitializationHttpModule>();
                RegisterServices(kernel);
                return kernel;
            }
            catch
            {
                kernel.Dispose();
                throw;
            }
        }

        /// <summary>
        /// Load your modules or register your services here!
        /// </summary>
        /// <param name="kernel">The kernel.</param>
        private static void RegisterServices(IKernel kernel)
        {
            //nbase
            kernel.Bind(typeof(IAppServiceBase<>)).To(typeof(AppServiceBase<>));
            kernel.Bind(typeof(IServiceBase<>)).To(typeof(ServiceBase<>));
            kernel.Bind(typeof(IRepositoryBase<>)).To(typeof(RepositoryBase<>));


            //Instituicao
            kernel.Bind<IInstituicaoAppService>().To<InstituicaoAppService>();
            kernel.Bind<IInstituicaoService>().To<InstituicaoService>();
            kernel.Bind<IInstituicaoRepository>().To<InstituicaoRepository>();

            //Formulario
            kernel.Bind<IFormularioAppService>().To<FormularioAppService>();
            kernel.Bind<IFormularioService>().To<FormularioService>();
            kernel.Bind<IFormularioRepository>().To<FormularioRepository>();



        }
    }
}