﻿

using Microsoft.AspNet.Identity;
using System.Configuration;
using System.Threading.Tasks;

using SendGrid;
using SendGrid.Helpers.Mail;

namespace biex.covid.forms.web.Models
{
    public class EmailService : IIdentityMessageService
    {
        public readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public Task SendAsync(IdentityMessage message)
        {

            return EnviarSendGridAsync(message);
        }


        //private async Task configSendGridasync(IdentityMessage message)
        //{
        //    log.Debug($"configurando sendgrid para envio de e-mail");
        //    log.Debug(message);
        //    //var apiKey = ConfigurationManager.AppSettings["API_SENDGRID_KEY"];
        //    //Email from = new Email(ConfigurationManager.AppSettings["API_SENDGRID_FROM"]);
        //    //Email to = new Email(message.Destination);
        //    //Content content = new Content("text/html", message.Body);
        //    //Mail mail = new Mail(from, message.Subject, to, content);
        //    //dynamic sg = new SendGridAPIClient(apiKey);
        //    //dynamic response = await sg.client.mail.send.post(requestBody: mail.Get());

        //}

        async Task EnviarSendGridAsync(IdentityMessage message)
        {
            var apiKey = ConfigurationManager.AppSettings["API_SENDGRID_KEY"];
            var client = new SendGridClient(apiKey);

            var from = new EmailAddress("noreply@estudosarita2.azurewebsites.net", "estudosarita2");
            var subject = message.Subject;
            var to = new EmailAddress(message.Destination.Trim());
            var htmlContent = message.Body;
            var msg = MailHelper.CreateSingleEmail(from, to, subject, string.Empty, htmlContent);


            log.Debug($"ENVIANDO_EMAIL|{message.Destination}|{message.Subject}|{message.Body}");

            var response = await client.SendEmailAsync(msg);

        }

        //public async Task SendAsyncRegular(string email, string assunto, string corpo)
        //{
        //    log.Debug($"ENVIANDO_EMAIL|{email}|{assunto}|{corpo}");

        //    //var apiKey = ConfigurationManager.AppSettings["API_SENDGRID_KEY"];
        //    //Email from = new Email(ConfigurationManager.AppSettings["API_SENDGRID_FROM"]);
        //    //Email to = new Email(email);
        //    //Content content = new Content("text/html", corpo);
        //    //Mail mail = new Mail(from, assunto, to, content);
        //    //dynamic sg = new SendGridAPIClient(apiKey);
        //    //dynamic response = await sg.client.mail.send.post(requestBody: mail.Get());

        //}

    }

}