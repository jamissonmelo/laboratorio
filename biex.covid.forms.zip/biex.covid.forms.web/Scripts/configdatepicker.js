﻿$(document).ready(function () {

    $(".dtp").each(function (idx, obj) {
        $(obj).val($(obj).val().substring(0, 10));
    });

    $(".dtp").datetimepicker({
        format: 'd/m/Y',
        lang: 'pt-BR',
        closeOnDateSelect: true,
        timepicker: false,
        scrollMonth: false

    });

    $.datetimepicker.setLocale('pt-BR');


});