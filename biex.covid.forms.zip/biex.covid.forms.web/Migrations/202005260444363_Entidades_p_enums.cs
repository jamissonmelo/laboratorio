﻿namespace biex.covid.forms.web.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Entidades_p_enums : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
