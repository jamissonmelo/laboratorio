namespace biex.covid.forms.web.Migrations
{
    using biex.covid.forms.web.Models;
    using Microsoft.AspNet.Identity;
    using Microsoft.AspNet.Identity.EntityFramework;
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<ApplicationDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(ApplicationDbContext context)
        {
            if (!context.Roles.Any(r => r.Name == "admin"))
            {
                var store = new RoleStore<IdentityRole>(context);
                var manager = new RoleManager<IdentityRole>(store);
                var role = new IdentityRole { Name = "admin" };

                manager.Create(role);
            }

            if (!context.Roles.Any(r => r.Name == "usuario"))
            {
                var store = new RoleStore<IdentityRole>(context);
                var manager = new RoleManager<IdentityRole>(store);
                var role = new IdentityRole { Name = "usuario" };

                manager.Create(role);
            }

            if (!context.Roles.Any(r => r.Name == "supervisor"))
            {
                var store = new RoleStore<IdentityRole>(context);
                var manager = new RoleManager<IdentityRole>(store);
                var role = new IdentityRole { Name = "supervisor" };

                manager.Create(role);
            }





            if (!context.Users.Any(u => u.UserName == "jamisson1@gmail.com"))
            {
                var store = new UserStore<ApplicationUser>(context);
                var manager = new UserManager<ApplicationUser>(store);
                var user = new ApplicationUser
                {
                    UserName = "jamisson1@gmail.com",
                    Ativo = true,
                    id_instituicao = -1,
                    Email = "jamisson1@gmail.com",
                    Nome = "Jamisson",
                    EmailConfirmed = true,
                    LockoutEnabled = false
                };

                manager.Create(user, "P@ssw0rd");
                manager.AddToRole(user.Id, "admin");

            }

            if (!context.Users.Any(u => u.UserName == "pedroleme@biof.ufrj.br"))
            {
                var store = new UserStore<ApplicationUser>(context);
                var manager = new UserManager<ApplicationUser>(store);
                var user = new ApplicationUser
                {
                    UserName = "pedroleme@biof.ufrj.br",
                    Ativo = true,
                    id_instituicao = 1,
                    Email = "pedroleme@biof.ufrj.br",
                    Nome = "Pedro Leme",
                    EmailConfirmed = true,
                    LockoutEnabled = false
                };

                manager.Create(user, "P@ssw0rd");
                manager.AddToRole(user.Id, "admin");

            }

            if (!context.Users.Any(u => u.UserName == "prmrocco@biof.ufrj.br"))
            {
                var store = new UserStore<ApplicationUser>(context);
                var manager = new UserManager<ApplicationUser>(store);
                var user = new ApplicationUser
                {
                    UserName = "prmrocco@biof.ufrj.br",
                    Ativo = true,
                    id_instituicao = 1,
                    Email = "prmrocco@biof.ufrj.br",
                    Nome = "Patricia Rocco",
                    EmailConfirmed = true,
                    LockoutEnabled = false
                };

                manager.Create(user, "P@ssw0rd");
                manager.AddToRole(user.Id, "admin");

            }
            
            if (!context.Users.Any(u => u.UserName == "christiane.correa@mctic.gov.br"))
            {
                var store = new UserStore<ApplicationUser>(context);
                var manager = new UserManager<ApplicationUser>(store);
                var user = new ApplicationUser
                {
                    UserName = "christiane.correa@mctic.gov.br",
                    Ativo = true,
                    id_instituicao = 2,
                    Email = "christiane.correa@mctic.gov.br",
                    Nome = "Christiane Correa",
                    EmailConfirmed = true,
                    LockoutEnabled = false
                };

                manager.Create(user, "P@ssw0rd");
                manager.AddToRole(user.Id, "admin");

            }

            if (!context.Users.Any(u => u.UserName == "apfernandes.ufmg@gmail.com"))
            {
                var store = new UserStore<ApplicationUser>(context);
                var manager = new UserManager<ApplicationUser>(store);
                var user = new ApplicationUser
                {
                    UserName = "Apfernandes.ufmg@gmail.com",
                    Ativo = true,
                    id_instituicao = 5,
                    Email = "apfernandes.ufmg@gmail.com",
                    Nome = "Ana Paula",
                    EmailConfirmed = true,
                    LockoutEnabled = false
                };

                manager.Create(user, "P@ssw0rd");
                manager.AddToRole(user.Id, "admin");

            }

            if (!context.Users.Any(u => u.UserName == "talita@atcgen.com.br"))
            {
                var store = new UserStore<ApplicationUser>(context);
                var manager = new UserManager<ApplicationUser>(store);
                var user = new ApplicationUser
                {
                    UserName = "talita@atcgen.com.br",
                    Ativo = true,
                    id_instituicao = 5,
                    Email = "talita@atcgen.com.br",
                    Nome = "Talita Neves",
                    EmailConfirmed = true,
                    LockoutEnabled = false
                };

                manager.Create(user, "P@ssw0rd");
                manager.AddToRole(user.Id, "admin");

            }
                                  
            if (!context.Users.Any(u => u.UserName == "gustavo.lobao@atcgen.com.br"))
            {
                var store = new UserStore<ApplicationUser>(context);
                var manager = new UserManager<ApplicationUser>(store);
                var user = new ApplicationUser
                {
                    UserName = "gustavo.lobao@atcgen.com.br",
                    Ativo = true,
                    id_instituicao = 6,
                    Email = "gustavo.lobao@atcgen.com.br",
                    Nome = "Gustavo Lob�o",
                    EmailConfirmed = true,
                    LockoutEnabled = false
                };

                manager.Create(user, "P@ssw0rd");
                manager.AddToRole(user.Id, "admin");

            }

            if (!context.Users.Any(u => u.UserName == "claudia@atcgen.com.br"))
            {
                var store = new UserStore<ApplicationUser>(context);
                var manager = new UserManager<ApplicationUser>(store);
                var user = new ApplicationUser
                {
                    UserName = "claudia@atcgen.com.br",
                    Ativo = true,
                    id_instituicao = 6,
                    Email = "claudia@atcgen.com.br",
                    Nome = "Claudia Viana",
                    EmailConfirmed = true,
                    LockoutEnabled = false
                };

                manager.Create(user, "P@ssw0rd");
                manager.AddToRole(user.Id, "admin");

            }

            if (!context.Users.Any(u => u.UserName == "luisbueno@qsbsoft.com.br"))
            {
                var store = new UserStore<ApplicationUser>(context);
                var manager = new UserManager<ApplicationUser>(store);
                var user = new ApplicationUser
                {
                    UserName = "luisbueno@qsbsoft.com.br",
                    Ativo = true,
                    id_instituicao = 6,
                    Email = "luisbueno@qsbsoft.com.br",
                    Nome = "luisbueno@qsbsoft.com.br",
                    EmailConfirmed = true,
                    LockoutEnabled = false
                };

                manager.Create(user, "P@ssw0rd");
                manager.AddToRole(user.Id, "admin");

            }

            if (!context.Users.Any(u => u.UserName == "katiane@atcgen.com.br"))
            {
                var store = new UserStore<ApplicationUser>(context);
                var manager = new UserManager<ApplicationUser>(store);
                var user = new ApplicationUser
                {
                    UserName = "katiane@atcgen.com.br",
                    Ativo = true,
                    id_instituicao = 6,
                    Email = "katiane@atcgen.com.br",
                    Nome = "Katiane Soares",
                    EmailConfirmed = true,
                    LockoutEnabled = false
                };

                manager.Create(user, "P@ssw0rd");
                manager.AddToRole(user.Id, "admin");

            }
            


        }

    }
}
