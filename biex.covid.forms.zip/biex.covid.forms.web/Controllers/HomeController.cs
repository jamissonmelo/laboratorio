﻿using biex.covid.forms.web.viewmodel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace biex.covid.forms.web.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var model = new DashViewmodel();

            //mock para layout
            model.DadosProgresso = new DashViewmodel.DadosProgressoViewmodel
            {
                GrupoA = 130,
                GrupoB = 190,
                TotalVagas = 500
            };



            return View(model);
        }

    }
}