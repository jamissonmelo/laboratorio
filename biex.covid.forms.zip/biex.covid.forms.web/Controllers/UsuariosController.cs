﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using biex.covid.forms.web.Models;
using Mapster;
using System.Collections.Generic;
using biex.covid.forms.web.viewmodel;
using biex.covid.forms.application.Interfaces;
using biex.utility;
using System.Data.Entity;

namespace biex.covid.forms.web.Controllers
{
    [Authorize]
    public class UsuariosController : BaseController
    {
        private ApplicationSignInManager _signInManager;
        private ApplicationUserManager _userManager;
        private readonly IInstituicaoAppService _instituicaoManager;




        public UsuariosController(IInstituicaoAppService svc)
        {
            _instituicaoManager = svc;
        }

        public UsuariosController(ApplicationUserManager userManager, ApplicationSignInManager signInManager, IInstituicaoAppService svc)
        {
            UserManager = userManager;
            SignInManager = signInManager;
            _instituicaoManager = svc;
        }


        public ApplicationSignInManager SignInManager
        {
            get
            {
                return _signInManager ?? HttpContext.GetOwinContext().Get<ApplicationSignInManager>();
            }
            private set
            {
                _signInManager = value;
            }
        }



        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }




        //
        // GET: /Manage/Index

        public ActionResult Index(ManageMessageId? message)
        {
            return RedirectToAction("List");
        }




        // GET: /Manage/ChangePassword
        public ActionResult ChangePassword()
        {
            return View();
        }

        //
        // POST: /Manage/ChangePassword
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            var result = await UserManager.ChangePasswordAsync(User.Identity.GetUserId(), model.OldPassword, model.NewPassword);
            if (result.Succeeded)
            {
                var user = await UserManager.FindByIdAsync(User.Identity.GetUserId());
                if (user != null)
                {
                    await SignInManager.SignInAsync(user, isPersistent: false, rememberBrowser: false);
                }
                return RedirectToAction("Index", new { Message = ManageMessageId.ChangePasswordSuccess });
            }
            AddErrors(result);
            return View(model);
        }

        //
        // GET: /Manage/SetPassword
        public ActionResult SetPassword()
        {
            return View();
        }

        //
        // POST: /Manage/SetPassword
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> SetPassword(SetPasswordViewModel model)
        {
            if (ModelState.IsValid)
            {
                var result = await UserManager.AddPasswordAsync(User.Identity.GetUserId(), model.NewPassword);
                if (result.Succeeded)
                {
                    var user = await UserManager.FindByIdAsync(User.Identity.GetUserId());
                    if (user != null)
                    {
                        await SignInManager.SignInAsync(user, isPersistent: false, rememberBrowser: false);
                    }
                    return RedirectToAction("Index", new { Message = ManageMessageId.SetPasswordSuccess });
                }
                AddErrors(result);
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }



        protected override void Dispose(bool disposing)
        {
            if (disposing && _userManager != null)
            {
                _userManager.Dispose();
                _userManager = null;
            }

            base.Dispose(disposing);
        }

        #region Helpers
        // Used for XSRF protection when adding external logins
        private const string XsrfKey = "XsrfId";

        private IAuthenticationManager AuthenticationManager
        {
            get
            {
                return HttpContext.GetOwinContext().Authentication;
            }
        }

        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error);
            }
        }

        private bool HasPassword()
        {
            var user = UserManager.FindById(User.Identity.GetUserId());
            if (user != null)
            {
                return user.PasswordHash != null;
            }
            return false;
        }

        private bool HasPhoneNumber()
        {
            var user = UserManager.FindById(User.Identity.GetUserId());
            if (user != null)
            {
                return user.PhoneNumber != null;
            }
            return false;
        }

        public enum ManageMessageId
        {
            AddPhoneSuccess,
            ChangePasswordSuccess,
            SetTwoFactorSuccess,
            SetPasswordSuccess,
            RemoveLoginSuccess,
            RemovePhoneSuccess,
            Error
        }

        #endregion



        //
        // GET: /Account/Login
        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        //
        // POST: /Account/Login
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login(LoginViewModel model, string returnUrl)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            //Encontra o usuário no repositório para verificar se o usuário es'ta desati
            // This doesn't count login failures towards account lockout
            // To enable password failures to trigger account lockout, change to shouldLockout: true
            var result = await SignInManager.PasswordSignInAsync(model.Email, model.Password, model.RememberMe, shouldLockout: false);
            switch (result)
            {
                case SignInStatus.Success:
                    var corr = Guid.NewGuid();
                    log.Info($"USUARIO_LOGADO|O usuário: {model.Email} foi autenticado com sucesso! verificando assciações|{corr}");


                    //verifica se o usuário está associado a alguma instituição
                    var usuario = await UserManager.FindByEmailAsync(model.Email);

                    if (!usuario.id_instituicao.HasValue)
                    {
                        ModelState.AddModelError("", "Erro ao efetuar o login, o usuário não possui associação com instituição. Solicite a correção do cadastro e tente novamente");
                        AuthenticationManager.SignOut(DefaultAuthenticationTypes.ApplicationCookie);
                        Session.Abandon();
                        log.Info($"ERRO_LOGIN_SEM_ASSOCIACAO|O usuário: {model.Email} foi autenticado com sucesso mas não está associado a nenhuma instituição|{corr}");
                        return View(model);
                    }

                    if (!usuario.Ativo)
                    {
                        ModelState.AddModelError("", "Erro ao efetuar o login, o usuário não está ativo");
                        AuthenticationManager.SignOut(DefaultAuthenticationTypes.ApplicationCookie);
                        Session.Abandon();
                        log.Info($"ERRO_LOGIN_INATIVO|O usuário: {model.Email} foi autenticado com sucesso! mas não está ativo|{corr}");
                        return View("Lockout");

                    }

                    log.Info($"USUARIO_LOGADO|O usuário: {model.Email} foi autenticado com sucesso! as associações foram verificadas com sucesso|{corr}");
                    return RedirectToLocal(returnUrl);


                case SignInStatus.LockedOut:
                    log.Info($"ERRO_LOGIN_CONTA_INATIVA|O usuário: {model.Email} Não foi autenticado com sucesso");
                    return View("Lockout");
                //case SignInStatus.RequiresVerification:
                //    return RedirectToAction("SendCode", new { ReturnUrl = returnUrl, RememberMe = model.RememberMe });
                case SignInStatus.Failure:
                default:
                    ModelState.AddModelError("", "Erro ao efetuar o login, verifique as credenciais e tente novamente.");
                    log.Info($"ERRO_LOGIN|O usuário: {model.Email} Não foi autenticado com sucesso");
                    return View(model);
            }
        }




        [AllowAnonymous]
        public ActionResult ForgotPassword()
        {
            return View();
        }

        //
        // POST: /Account/ForgotPassword
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ForgotPassword(ForgotPasswordViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = await UserManager.FindByNameAsync(model.Email);
                if (user == null)
                {
                    // Don't reveal that the user does not exist or is not confirmed
                    log.Warn($"O usuário  tentou resetar a senha. Usuário não encontrado! {model.Email}");
                    return View("ForgotPasswordConfirmation");

                }

                string code = await UserManager.GeneratePasswordResetTokenAsync(user.Id);
                log.Warn($"Usuário {model.Email} reiniciou a senha com sucesso!");
                var callbackUrl = Url.Action("ResetPassword", "Usuarios", new { userId = user.Id, code = code }, protocol: Request.Url.Scheme);
                await UserManager.SendEmailAsync(user.Id, "Criar nova senha", "Para reiniciar sua senha, <a href=\"" + callbackUrl + "\">clique aqui</a>");
                return RedirectToAction("ForgotPasswordConfirmation", "Usuarios");
            }
            
            return View(model);
        }

        //
        // GET: /Account/ForgotPasswordConfirmation
        [AllowAnonymous]
        public ActionResult ForgotPasswordConfirmation()
        {
            return View();
        }

        //
        // GET: /Account/ResetPassword
        [AllowAnonymous]
        public ActionResult ResetPassword(string code)
        {
            return code == null ? View("Error") : View();
        }

        //
        // POST: /Account/ResetPassword
        [HttpPost]
        [AllowAnonymous]
        public async Task<ActionResult> ResetPassword(ResetPasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            var user = await UserManager.FindByNameAsync(model.Email);
            if (user == null)
            {
                // Don't reveal that the user does not exist
                return RedirectToAction("ResetPasswordConfirmation", "Usuarios");
            }
            var result = await UserManager.ResetPasswordAsync(user.Id, model.Code, model.Password);
            if (result.Succeeded)
            {
                return RedirectToAction("ResetPasswordConfirmation", "Usuarios");
            }
            AddErrors(result);
            return View();
        }

        //
        // GET: /Account/ResetPasswordConfirmation
        [AllowAnonymous]
        public ActionResult ResetPasswordConfirmation()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            AuthenticationManager.SignOut(DefaultAuthenticationTypes.ApplicationCookie);
            return RedirectToAction("Index", "Home");
        }


        #region Helpers

        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            return RedirectToAction("Index", "Home");
        }

        internal class ChallengeResult : HttpUnauthorizedResult
        {
            public ChallengeResult(string provider, string redirectUri)
                : this(provider, redirectUri, null)
            {
            }

            public ChallengeResult(string provider, string redirectUri, string userId)
            {
                LoginProvider = provider;
                RedirectUri = redirectUri;
                UserId = userId;
            }

            public string LoginProvider { get; set; }
            public string RedirectUri { get; set; }
            public string UserId { get; set; }

            public override void ExecuteResult(ControllerContext context)
            {
                var properties = new AuthenticationProperties { RedirectUri = RedirectUri };
                if (UserId != null)
                {
                    properties.Dictionary[XsrfKey] = UserId;
                }
                context.HttpContext.GetOwinContext().Authentication.Challenge(properties, LoginProvider);
            }
        }
        #endregion




        #region CRUD


        private readonly ChaveValor[] ListaNiveis = new ChaveValor[]
        {
            new ChaveValor { Id=1, Nome = "Usuário"},
            new ChaveValor { Id=2, Nome = "Supervisor"},
            new ChaveValor { Id=3, Nome = "Administrador"},

        };


        #region API
        [Authorize(Roles = "admin")]
        public JsonResult GetJson()
        {

            var usuarios = UserManager.Users.Include(u => u.Roles).ToList();
            var instituicoes = _instituicaoManager.GetAll().ToList();




            var model = from u in usuarios
                        join i in instituicoes on u.id_instituicao equals i.Id
                        select new UsuarioViewmodel
                        {
                            Id = u.Id,
                            Nome = u.Nome,
                            Email = u.Email,
                            id_instituicao = u.id_instituicao ?? 0,
                            Instituicao = i.Nome ?? "Sem associação com instiuição",
                            Administrador = UserManager.IsInRole(u.Id, "admin"),
                            Supervisor = UserManager.IsInRole(u.Id, "supervisor"),
                            Ativo = u.Ativo
                        };


            return new JsonResult2 { Data = new { data = model } };
        }

        [Authorize(Roles = "admin")]
        public async Task<JsonResult> Ativar(string Id)
        {
            var usuario = await UserManager.FindByIdAsync(Id);
            usuario.Ativo = !usuario.Ativo;
            await UserManager.UpdateAsync(usuario);
            return Json("ok");
        }

        #endregion



        [Authorize(Roles = "admin")]
        [HttpGet]
        public ActionResult List()
        {
            return View();
        }
        #endregion

        [HttpGet]
        [Authorize(Roles = "admin")]
        public ActionResult Criar()
        {
            #region preparação
            ViewBag.Instituicoes = _instituicaoManager.GetAll().Adapt<IEnumerable<InstituicaoViewmodel>>();
            ViewBag.Permissoes = ListaNiveis;
            #endregion

            return View();

        }


        [HttpPost]
        [Authorize(Roles = "admin")]
        public async Task<ActionResult> Criar(UsuarioViewmodel model)
        {


            try
            {
                //verifica se o modelo é válido
                if (ModelState.IsValid)
                {
                    var corr = Guid.NewGuid();

                    //Cria o log da inclusão
                    log.Info($"USUARIO|Inicou a criação do item|{model.Email}|{User.Identity.Name}|{corr}");

                    //Cria o usuário
                    ApplicationUser objUsuario = new ApplicationUser();
                    objUsuario.Ativo = true;
                    objUsuario.Email = model.Email;
                    objUsuario.Nome = model.Nome;
                    objUsuario.UserName = model.Email;
                    objUsuario.id_instituicao = model.id_instituicao;
                    objUsuario.LockoutEnabled = false;
                    objUsuario.EmailConfirmed = true;



                    var result = await UserManager.CreateAsync(objUsuario);

                    //cria a permissão
                    if (model.id_permissao == 2)
                    {
                        UserManager.AddToRole(objUsuario.Id, "supervisor");
                    }
                    else if (model.id_permissao == 3)
                    {
                        UserManager.AddToRole(objUsuario.Id, "admin");
                    }
                    else
                    {
                        UserManager.AddToRole(objUsuario.Id, "usuario");
                    }





                    if (!result.Succeeded)
                    {
                        var strErros = result.Errors != null ? result.Errors.ToArray().ToStringSeparada(",") : "Não identificado";
                        throw new Exception(strErros);
                    }

                    log.Info($"USUARIO|Criou o item|{model.Email} ID: {model.Id} |Permissao: {model.id_permissao}|{User.Identity.Name}|{corr}");
                    //enviar o link com senha para o e-mail do usuário 


                    string code = await UserManager.GeneratePasswordResetTokenAsync(objUsuario.Id);
                    var callbackUrl = Url.Action("ResetPassword", "Usuarios", new { userId = objUsuario.Id, code = code }, protocol: Request.Url.Scheme);

                    var strTemplate = $"<p>Prezado(a) {objUsuario.Nome} <br/>Bem vindo(a) ao estudosarita2</p>" +
                        $"Para criar sua senha, <a href=\"{callbackUrl}\">clique aqui</a>";

                    await UserManager.SendEmailAsync(objUsuario.Id, "Criar nova senha", strTemplate);


                    TempData["Mensagem"] = "Usuário criado com sucesso. A senha foi enviada para o e-mail cadastrado";
                    //redireciona para a view de listagem 
                    return RedirectToAction("List");
                }
                else //erro de validação. Logar o erro
                {
                    throw new Exception($"Erro de validação do modelo");
                }
            }
            catch (Exception ex)
            {
                //seta a mensagem de erro
                var strErro = $"Erro ao processar o comando o erro foi: {ex.Message}";
                //loga o erro e a exception
                log.Error(strErro);
                log.Error(ex);

                //seta a mensagem de retorno
                TempData["Mensagem"] = strErro;

                #region preparação
                ViewBag.Instituicoes = _instituicaoManager.GetAll().Adapt<IEnumerable<InstituicaoViewmodel>>();
                ViewBag.Permissoes = ListaNiveis;
                #endregion


                //retorna para a view preenchida
                return View(model);
            }





        }


        [HttpGet]
        [Authorize(Roles = "admin")]
        public async Task<ActionResult> Editar(string Id)
        {

            #region preparação
            ViewBag.Instituicoes = _instituicaoManager.GetAll().Adapt<IEnumerable<InstituicaoViewmodel>>();
            ViewBag.Permissoes = ListaNiveis;
            #endregion

            var usuario = await UserManager.FindByIdAsync(Id);
            var instituicao = _instituicaoManager.GetById(usuario.id_instituicao.Value);
            var model = new UsuarioViewmodel
            {
                Id = usuario.Id,
                Nome = usuario.Nome,
                Email = usuario.Email,
                id_instituicao = usuario.id_instituicao ?? 0,
                Instituicao = instituicao.Nome ?? "Sem associação com instiuição",
                Ativo = usuario.Ativo,

            };

            if (UserManager.IsInRole(model.Id, "admin"))
            {
                model.Administrador = true;
                model.id_permissao = 3;
            }
            else if (UserManager.IsInRole(model.Id, "supervisor"))
            {
                model.Supervisor = true;
                model.id_permissao = 2;
            }
            else
            {
                model.id_permissao = 1;
            }


            return View(model);

        }

        [HttpPost]
        [Authorize(Roles = "admin")]
        public async Task<ActionResult> Editar(UsuarioViewmodel model)
        {
            try
            {
                var usuario = await UserManager.FindByIdAsync(model.Id);
                if (usuario == null) throw new Exception("Item não encontrado");

                usuario.id_instituicao = model.id_instituicao;
                usuario.Nome = model.Nome;
                usuario.Email = model.Email;
                usuario.UserName = model.Email;
                UserManager.Update(usuario);


                //remove as roles do usuário 
                UserManager.RemoveFromRoles(usuario.Id, new[] { "admin", "supervisor", "usuario" });
                //adiciona as rolas novas

                //cria a permissão
                if (model.id_permissao == 2)
                {
                    UserManager.AddToRole(usuario.Id, "supervisor");
                }
                else if (model.id_permissao == 3)
                {
                    UserManager.AddToRole(usuario.Id, "admin");
                }
                else
                {
                    UserManager.AddToRole(usuario.Id, "usuario");
                }


                TempData["Mensagem"] = "Usuário modificado com sucesso.";
                log.Warn($"USUARIO_ALTERADO|Usuário {User.Identity.GetUserId()} alterou o usuário: {usuario.Id} {usuario.Nome} permissão: {model.id_permissao}");
                //redireciona para a view de listagem 
                return RedirectToAction("List");
            }
            catch (Exception ex)
            {
                //seta a mensagem de erro
                var strErro = $"Erro ao processar o comando o erro foi: {ex.Message}";
                //loga o erro e a exception
                log.Error(strErro);
                log.Error(ex);

                //seta a mensagem de retorno
                TempData["Mensagem"] = strErro;

                #region preparação
                ViewBag.Instituicoes = _instituicaoManager.GetAll().Adapt<IEnumerable<InstituicaoViewmodel>>();
                ViewBag.Permissoes = ListaNiveis;
                #endregion

                //retorna para a view preenchida
                return View(model);
            }




        }




    }



}