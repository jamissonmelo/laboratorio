﻿using biex.covid.forms.application.Interfaces;
using biex.covid.forms.web.viewmodel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mapster;
using biex.utility;
using System.Web.UI;
using System.Configuration;

namespace biex.covid.forms.web.Controllers
{
    
    public class ApiController : BaseController
    {
        private readonly IFormularioAppService svcFormulario;
        public ApiController(IFormularioAppService _svc1)
        {
            svcFormulario = _svc1;
        }     


        [AllowAnonymous]
        public JsonResult Formulario()
        {

            var falha = true;
            //valida o token
            var strToken = Request.Headers["API_KEY"] ?? Request.Params["API_KEY"];

            if (string.IsNullOrEmpty(strToken))
            {
                log.Warn($"Erro de conexão não autorizada. API Key não informado IP:{Request.UserHostAddress} Hn: {Request.UserHostName}");
            }
            else
            {
                if (ConfigurationManager.AppSettings["API_KEY"] != strToken)
                {
                    log.Warn($"Erro de conexão não autorizada. API Key informada: {strToken} IP: {Request.UserHostAddress} Hn: {Request.UserHostName}");
                    falha = true;
                }
                else //sucesso
                {
                    log.Info($"Request executado na api com sucesso. IP:{Request.UserHostAddress} Hn: {Request.UserHostName}");
                    falha = false;
                }
            }

            if (falha)
            {
                return Json(new
                {
                    Resultado = "Falha",
                    Mensagem = "Acesso negado. o parâmetro com a API_KEY não foi passado no header ou no POST ou está inválido"
                }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                var formularios = svcFormulario.GetAll().Adapt<IEnumerable<ExportExcelLiteViewmodel>>().ToList();
                var grupos = svcFormulario.GetGrupos().ToList();

                foreach (var item in formularios)
                {
                    var gr = grupos.FirstOrDefault(x => x.Id == item.Id);
                    item.Grupo = gr == null ? "" : gr.Grupo;
                    item.status = Util.ObterStatus(item);
                }

                return Json(formularios, JsonRequestBehavior.AllowGet);
            }


        }

    }
}