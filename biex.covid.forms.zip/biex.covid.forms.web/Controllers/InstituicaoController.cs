﻿using biex.covid.forms.application.Interfaces;
using biex.covid.forms.domain.entidades;
using biex.covid.forms.web.viewmodel;
using Mapster;
using Microsoft.AspNet.Identity.Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace biex.covid.forms.web.Controllers
{
    [Authorize(Roles = "admin")]
    public class InstituicaoController : BaseController
    {
        private readonly IInstituicaoAppService svcMain;

        public InstituicaoController(IInstituicaoAppService svc1)
        {
            svcMain = svc1;

        }


        #region API 
        public JsonResult GetJson()
        {
            //instancia as entidades já carregando do serviço 
            var entidade = svcMain.GetAll().Adapt<IEnumerable<InstituicaoViewmodel>>().ToArray();

            //Mapeia para a viewmodel --> não se deve retornar o modelo direto sem uma viewmodel pois como ele tem muitos relacionamentos, pode arriscar
            //carregar todos os dados do sistema no mesmo ajax, o que travaria o navegador e o servidor 
            var viewmodel = entidade.Adapt<IEnumerable<InstituicaoViewmodel>>();

            //Retorna o tipo especial (JsonResult2) que é uma derivação do jsonresult tradicional, só que com um leve tratamento nas datas
            //para facilitar o uso no jquery datatables grid
            return new JsonResult2 { Data = new { data = viewmodel } };
        }


        [HttpPost]
        public JsonResult Delete(int id)
        {

            //encontra a entidade 
            var entidade = svcMain.GetById(id);
            if (entidade == null) throw new HttpException(404, "Item não encontrado");

            if (entidade.Formularios != null && entidade.Formularios.Count > 0) throw new HttpException("Não é possível excluir uma instituição que contenha dados de formulários associados. Modifique os formulários e tente novamente");


            //verificar se existem usuários associados a instiuição
            var svcUserManager = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            var qtdUsuarios = svcUserManager.Users.Count(x => x.id_instituicao == id);
            if (qtdUsuarios > 0) throw new HttpException("Não é possível excluir uma instituição que contenha usuários associados. Modifique os usuários e tente novamente");

            try
            {
                //deleta a entidade
                svcMain.Remove(entidade);
                log.Info($"Instituicao|Item removido|{entidade.Id} - {entidade.Nome}|{User.Identity.Name}");

            }
            catch (Exception ex)
            {
                log.Error($"Erro ao excluir o ID {id} o erro foi: {ex.Message}", ex);
                throw ex;
            }
            //retorna o sucesso
            return Json("Item excluído com sucesso");

        }



        #endregion

        // GET: Instituicao
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Criar()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Criar(InstituicaoViewmodel model)
        {
            try
            {
                //verifica se o modelo é válido
                if (ModelState.IsValid)
                {
                    //transforma a viewmodel na entidade de banco 
                    var entidade = model.Adapt<Instituicao>();

                    //chama o serviço para inserir a entidade no banco 
                    svcMain.Add(entidade);

                    //Cria o log da inclusão
                    log.Info($"Instituicao|Item criado|{entidade.Id}|{User.Identity.Name}");

                    //seta a mensagem de retorno 

                    TempData["Mensagem"] = "Item criado com sucesso";
                    //redireciona para a view de listagem 
                    return RedirectToAction("Index");
                }
                else //erro de validação. Logar o erro
                {
                    throw new Exception($"Erro de validação do modelo");
                }
            }
            catch (Exception ex)
            {
                //seta a mensagem de erro
                var strErro = $"Erro ao processar o comando o erro foi: {ex.Message}";
                //loga o erro e a exception
                log.Error(strErro);
                log.Error(ex);

                //seta a mensagem de retorno
                TempData["Mensagem"] = strErro;

                //retorna para a view preenchida
                return View(model);
            }




        }

        [HttpGet]
        public ActionResult Editar(int id)
        {


            var entidade = svcMain.GetById(id);
            if (entidade == null) throw new HttpException(404, "Item não encontrado");
            var model = entidade.Adapt<InstituicaoViewmodel>();
            return View(model);

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Editar(InstituicaoViewmodel model)
        {
            try
            {
                //verifica se o modelo é válido
                if (ModelState.IsValid)
                {
                    var entidade = svcMain.GetById(model.Id);
                    if (entidade == null) throw new HttpException(404, "Item não encontrado");
                    entidade.Nome = model.Nome;

                    svcMain.Update(entidade);
                    //Cria o log da inclusão
                    log.Info($"Instituicao|Item modificado|{entidade.Id} - {entidade.Nome} passou para: {model.Nome}|{User.Identity.Name}");

                    //seta a mensagem de retorno 
                    TempData["Mensagem"] = "Item modificado com sucesso";
                    //redireciona para a view de listagem 
                    return RedirectToAction("Index");
                }
                else
                {
                    throw new Exception($"Erro de validação do modelo");
                }
            }
            catch (Exception ex)
            {
                //seta a mensagem de erro
                var strErro = $"Erro ao processar o comando o erro foi: {ex.Message}";
                //loga o erro e a exception
                log.Error(strErro);
                log.Error(ex);

                //seta a mensagem de retorno
                TempData["Mensagem"] = strErro;

                //retorna para a view preenchida
                return View(model);

            }

        }






    }
}