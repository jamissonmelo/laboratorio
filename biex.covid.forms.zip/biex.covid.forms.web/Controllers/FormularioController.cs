﻿using biex.covid.forms.application.Interfaces;
using System.Web.Mvc;
using System.Linq;
using Microsoft.AspNet.Identity;
using Mapster;
using biex.covid.forms.web.viewmodel;
using System.Collections.Generic;
using biex.covid.forms.domain.entidades;
using System.Web;
using System;
using Microsoft.AspNet.Identity.Owin;
using biex.utility;
using OfficeOpenXml;
using System.IO;
using OfficeOpenXml.Style;
using Syncfusion.DocIO.DLS;
using Syncfusion.DocIO;
using Syncfusion.DocToPDFConverter;
using Syncfusion.Pdf;
using System.Configuration;
using biex.covid.forms.web.Models;


namespace biex.covid.forms.web.Controllers
{
    [Authorize]
    public class FormularioController : BaseController
    {
        #region CTOR
        private readonly IFormularioAppService svcMain;
        public FormularioController(IFormularioAppService _svc1)
        {
            svcMain = _svc1;
        }

        ApplicationUser _usuario => HttpContext.GetOwinContext().Get<ApplicationSignInManager>().UserManager.FindById(User.Identity.GetUserId());


        #endregion

        #region INDEX
        // GET: Formulario
        public ActionResult Index()
        {
            return View();
        }
        #endregion

        #region API

        public JsonResult GetJsonFormularios()
        {
            //var _usuario = HttpContext.GetOwinContext().Get<ApplicationSignInManager>().UserManager.FindById(User.Identity.GetUserId());


            List<FormularioList> entidades = new List<FormularioList>();

            List<GrupoPaciente> grupos = svcMain.GetGrupos().ToList();//traz os grupos pra memória

            if (User.IsInRole("admin") || User.IsInRole("supervisor"))
            {
                entidades = svcMain.GetHomeData().ToList();
            }
            else
            {
                entidades = svcMain.GetHomeData().Where(x => x.id_instituicao == _usuario.id_instituicao).ToList();
            }
            //carrega os fomrulários que o usário pode visualizar


            //var formularios = from f in entidades
            //                  join gr in grupos on f.Id equals gr.Id into ss
            //                  from subgrupo in ss.DefaultIfEmpty()
            //                  select new ResultadoListViewmodel


            var viewmodel = from e in entidades
                            join gr in grupos on e.Id equals gr.Id into ss
                            from subgrupo in ss.DefaultIfEmpty()
                            select new FormularioListViewmodel
                            {
                                Id = e.Id,
                                date_enrolled = e.date_enrolled,
                                first_name = e.first_name,
                                last_name = e.last_name,
                                cpf_d1 = e.cpf_d1,
                                grupo = subgrupo != null ? subgrupo.Grupo : string.Empty,
                                d1 = e.d1,
                                d3 = e.d3,
                                d8 = e.d8,
                                covid_d1 = !e.covid_d1.HasValue ? "Em processamento" : e.covid_d1.Value ? "Positivo" : "Negativo",
                                covid_d1_v2 = !e.covid_d1_v2.HasValue ? "Em processamento" : e.covid_d1_v2.Value ? "Positivo" : "Negativo",
                                interna_d1_v2_desc = (e.pacientevivo.HasValue && !e.pacientevivo.Value) ? "Óbito" : e.interna_d1_v2_desc ?? string.Empty,
                                pacientevivo = e.pacientevivo,
                                instituicao = e.NomeInstituicao,
                                pacienteretornou_d3 = e.pacienteretornou_d3,
                                dsc_pacienteretornou_d3 = e.dsc_pacienteretornou_d3,


                            };

            return new JsonResult2 { Data = new { data = viewmodel } };
        }

        public FileResult GetPatientDocument(int Id)
        {
            var entidade = svcMain.GetById(Id);

            if (entidade == null) throw new HttpException(404, "Não foi possível encontrar o item");

            //var _usuario = HttpContext.GetOwinContext().Get<ApplicationSignInManager>().UserManager.FindById(User.Identity.GetUserId());
            if ((!User.IsInRole("admin") && !User.IsInRole("supervisor")) && entidade.id_instituicao != _usuario.id_instituicao) throw new HttpException(403, "Não Autorizado");

            return File(entidade.patient_document, System.Net.Mime.MediaTypeNames.Application.Octet, entidade.patient_document_filename);
        }

        [HttpPost]
        public JsonResult ControleValido(string codigocontrole, string Id)
        {
            int id_controle = 0;
            int id_formulario = 0;

            if (int.TryParse(codigocontrole, out id_controle))
            {
                if (id_controle == 0) return Json(true);
            }
            else
            {
                return Json(true);
            }

            int.TryParse(Id, out id_formulario);

            Formulario ent;

            ent = svcMain.GetByCodigoControle(id_controle);
            return Json((ent == null || ent.Id == id_formulario));
        }

        [HttpPost]
        [AllowAnonymous]
        public JsonResult MaiorDeIdade(string dob)
        {
            try
            {
                var dt = DateTime.ParseExact(dob, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);

                if (dt <= DateTime.Now.AddYears(-18))
                {
                    return Json(true);
                }
                else
                {
                    return Json("O paciente precisa ter mais de 18 anos.");
                }
            }
            catch
            {
                return Json("Data inválida");
            }
        }

        public JsonResult CPFValido(string cpf_d1, string Id)
        {
            if (!Util.CPFValido(cpf_d1))
            {
                return Json("CPF Inválido");
            }

            int id_formulario = 0;
            int.TryParse(Id, out id_formulario);

            Formulario ent;
            ent = svcMain.GetByCPF(cpf_d1);
            if ((ent == null || ent.Id == id_formulario))
            {
                return Json(true);
            }
            else
            {
                return Json("O CPF está em uso em outro paciente");
            }
        }

        [Authorize(Roles = "admin,supervisor")]
        public FileResult ExportToExcel()
        {

            try
            {

                ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
                MemoryStream stream = new MemoryStream();


                var formularios = svcMain.GetAllOnline().Adapt<IEnumerable<ExportExcelViewmodel>>().ToList();


                var grupos = svcMain.GetGrupos().ToList();


                foreach (var item in formularios)
                {
                    var gr = grupos.FirstOrDefault(x => x.Id == item.Id);
                    item.Grupo = gr == null ? "" : gr.Grupo;

                    item.codigocontrole = item.codigocontrole != null ? ConfigurationManager.AppSettings["PREFIXO_CONTROLE"] + item.codigocontrole.PadLeft(5, '0') : "";

                    item.telephone_2 = string.IsNullOrEmpty(item.telephone_2) ? "FALSE" : item.telephone_2;

                }

                using (var excel = new ExcelPackage(stream))
                {
                    // name of the sheet 
                    var workSheet = excel.Workbook.Worksheets.Add("Pacientes");
                    workSheet.Cells[1, 1].LoadFromCollection(formularios, true);
                    workSheet.Row(1).Height = 20;
                    workSheet.Row(1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    workSheet.Row(1).Style.Font.Bold = true;

                    var dts = new[] { 3, 9, 30, 32, 40, 57, 59, 61 };
                    foreach (var i in dts)
                    {
                        workSheet.Column(i).Style.Numberformat.Format = "dd/mm/yyyy";
                    }

                    var wsGrupos = excel.Workbook.Worksheets.Add("Grupos");
                    wsGrupos.Cells[1, 1].LoadFromCollection(grupos, true);
                    wsGrupos.Row(1).Height = 20;
                    wsGrupos.Row(1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    wsGrupos.Row(1).Style.Font.Bold = true;



                    excel.Save();
                }

                return File(stream.ToArray(), System.Net.Mime.MediaTypeNames.Application.Octet, $"{DateTime.Now.ToString("yyyy-MM-dd_HHmm")}_ExportExcel.xlsx");

            }
            catch (Exception ex)
            {
                log.Error(ex);
                log.Error($"Erro ao exportar o excel. Usuário: {User.Identity.GetUserName()}");
                throw (ex);
            }

        }


        [Authorize(Roles = "admin,supervisor")]
        public FileResult ExportToExcelLite()
        {

            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            MemoryStream stream = new MemoryStream();

            var formularios = svcMain.GetAllOnline().Adapt<IEnumerable<ExportExcelLiteViewmodel>>().ToList();
            var grupos = svcMain.GetGrupos().ToList();


            foreach (var item in formularios)
            {
                var gr = grupos.FirstOrDefault(x => x.Id == item.Id);
                item.Grupo = gr == null ? "" : gr.Grupo;
                item.status = Util.ObterStatus(item);
            }

            using (var excel = new ExcelPackage(stream))
            {
                // name of the sheet 
                var workSheet = excel.Workbook.Worksheets.Add("Pacientes");
                workSheet.Cells[1, 1].LoadFromCollection(formularios, true);
                workSheet.Row(1).Height = 20;
                workSheet.Row(1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                workSheet.Row(1).Style.Font.Bold = true;

                var dts = new[] { 16, 17, 19 };
                foreach (var i in dts)
                {
                    workSheet.Column(i).Style.Numberformat.Format = "dd/mm/yyyy";
                }

                //remove as colunas temporárias    
                workSheet.DeleteColumn(21, 99);


                var wsGrupos = excel.Workbook.Worksheets.Add("Grupos");
                wsGrupos.Cells[1, 1].LoadFromCollection(grupos, true);
                wsGrupos.Row(1).Height = 20;
                wsGrupos.Row(1).Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                wsGrupos.Row(1).Style.Font.Bold = true;
                excel.Save();
            }

            return File(stream.ToArray(), System.Net.Mime.MediaTypeNames.Application.Octet, $"{DateTime.Now.ToString("yyyy-MM-dd_HHmm")}_ExportExcelLT.xlsx");

        }


        #endregion

        #region DominiosComuns

        private readonly dynamic ListaPositivoNegativo = new[]
        {
            new {Id= true, Nome="Positivo" } ,
            new {Id=false, Nome="Negativo"}
        };

        private readonly dynamic ListaSimNao = new[]
        {
                new {Id= true , Nome="Sim"} ,
                new {Id= false, Nome= "Não"}
        };

        private readonly dynamic ListaSexos = new[]  {
                new { Nome = "Feminino" } ,
                new { Nome = "Masculino" }
        };

        private readonly dynamic ListaRacas = new[] {
                new {Id=0,Nome="Branca"} ,
                new {Id=1,Nome="Preta"},
                new {Id=5,Nome="Parda"},
                new {Id=2,Nome="Indígena"},
                new {Id=3, Nome="Amarela" },
                new {Id=4, Nome="Desconhecida/Não Especificada" }
        };

        private readonly ChaveValor[] ListaResultadoInternacao = new ChaveValor[] {
            new ChaveValor { Id=1,Nome="Enfermaria" },
            new ChaveValor { Id=1,Nome="CTI" },
            new ChaveValor { Id=0,Nome="No estudo" },
            new ChaveValor { Id=0,Nome="Desistiu" }
        };

        private readonly ChaveValor[] ListaNivel = new ChaveValor[]
        {
            new ChaveValor { Id=1, Nome = "Leve"},
            new ChaveValor { Id=1, Nome = "Moderada"},
            new ChaveValor { Id=1, Nome = "Grave"},
            new ChaveValor { Id=1, Nome = "Muito Grave"}
        };

        private readonly ChaveValor[] ListaComorbidades = new ChaveValor[]
        {

                new ChaveValor {Id=1, Nome = "Nenhum" },
                new ChaveValor {Id=2, Nome = "DM" },
                new ChaveValor {Id=3, Nome = "HAS" },
                new ChaveValor {Id=4, Nome = "Asma" },
                new ChaveValor {Id=5, Nome = "DPOC (Gold1)" },
                new ChaveValor {Id=6, Nome = "DPOC (Gold2)" },
                new ChaveValor {Id=7, Nome = "Insuficiência Renal"},
                new ChaveValor {Id=7, Nome = "Insuficiência Hepática"}
        };


        private readonly ChaveValor[] ListaSintomas = new ChaveValor[]
        {
                new ChaveValor {Id= 1 , Nome="Nenhum"} ,
                new ChaveValor {Id= 2 , Nome="Tosse seca"} ,
                new ChaveValor {Id= 3 , Nome="Tosse produtiva"},
                new ChaveValor{ Id=4, Nome="Dor de garganta"},
//                new ChaveValor{Id=5, Nome="Dificuldade de respirar"},
                new ChaveValor {Id=6, Nome="Febre"},
                new ChaveValor {Id=7,Nome="Fadiga"}
        };

        private readonly ChaveValor[] ListaEfeitosAdversos = new ChaveValor[]
        {
                new ChaveValor {Id=1,Nome="Urticária"},
                new ChaveValor {Id=2,Nome="Angioedema"},
                new ChaveValor {Id=3,Nome="Anorexia"},
                new ChaveValor {Id=4,Nome="Labilidade Emocional"},
                new ChaveValor {Id=5,Nome="Cefaleia"},
                new ChaveValor {Id=6,Nome="Alterações Visuais"},
                new ChaveValor {Id=7,Nome="Náusea"},
                new ChaveValor {Id=8,Nome="Diarreia"},
                new ChaveValor {Id=9,Nome="Vômito"},
                new ChaveValor {Id=10,Nome="Erupção Cutânea"},
                new ChaveValor {Id=11,Nome="Prurido"}
        };

        private readonly ChaveValor[] ListaEscolaridade = new ChaveValor[]
        {
            new ChaveValor {Id=0, Nome="Analfabeto"},
            new ChaveValor {Id=1, Nome="Ensino básico"},
            new ChaveValor {Id=2, Nome="Ensino fundamental"},
            new ChaveValor {Id=3, Nome="Ensino médio"},
            new ChaveValor {Id=4, Nome="Ensino superior"}
        };


        public readonly ChaveValor[] ListaMotivoNaoRetorno = new ChaveValor[]
        {//Caso Não, qual o motivo? a) Desistiu, b) Internado, c) óbito
            new ChaveValor{ Id=1, Nome="Desistiu"},
            new ChaveValor{ Id=2, Nome="Internado"},
            new ChaveValor{ Id=3, Nome="Óbito"}
        };


        #endregion

        #region DEMOGRAFIA

        [HttpGet]
        public ActionResult CriarDemografia()
        {
            //supervisor não pode gravar nada
            if (User.IsInRole("supervisor")) throw new HttpException(403, "Não autorizado!");

            #region dominios
            ViewBag.Sexos = ListaSexos;
            ViewBag.Racas = ListaRacas;
            ViewBag.Comorbidades = ListaComorbidades;
            ViewBag.SimNao = ListaSimNao;
            ViewBag.Escolaridades = ListaEscolaridade;
            #endregion

            //demografia
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CriarDemografia(DemografiaViewmodel model)
        {
            //supervisor não pode gravar nada
            if (User.IsInRole("supervisor")) throw new HttpException(403, "Não autorizado!");

            try
            {
                if (ModelState.IsValid)
                {
                    //caso tenha anexo
                    if (model.patient_document_file != null)
                    {
                        byte[] arr = new byte[model.patient_document_file.ContentLength];
                        model.patient_document_file.InputStream.Read(arr, 0, model.patient_document_file.ContentLength);
                        model.patient_document = arr;
                        model.patient_document_mime = model.patient_document_file.ContentType;
                        model.patient_document_filename = model.patient_document_file.FileName;
                    }
                    else
                    {

                        ModelState.AddModelError("patient_document_file", "O Upload do TCLE é obrigatório");
                        throw new Exception("O Upload do TCLE é obrigatório");
                    }

                    //comorbidades
                    model.comorbidade = model.comorbidade_arr.ToStringSeparada("|");


                    //monta o objeto da entidade
                    var entidade = model.Adapt<Formulario>();

                    //carrega os dados do usuário para vincular no formulário
                    var UserManager = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
                    var usuario = UserManager.FindById(User.Identity.GetUserId());

                    entidade.id_usuario = usuario.Id;
                    entidade.id_instituicao = usuario.id_instituicao.Value;


                    //grava o formulário D-0 no banco 
                    svcMain.Add(entidade);

                    //Grava o grupo original do paciente.
                    var grupoOriginal = svcMain.GetGrupos().Where(x => x.Id == entidade.Id).First();
                    entidade.grupooriginal = grupoOriginal.Grupo;
                    svcMain.Update(entidade);




                    log.Info($"FORMULARIO_D0|Criou o item|{model.Id} ID: {model.Id}|{User.Identity.Name}");


                    TempData["Mensagem"] = "Formulário adicionado com sucesso.";
                    //redireciona para a view de listagem 
                    return RedirectToAction("Index");
                }
                else
                {
                    throw new Exception("Erro de validação no modelo. Verifique o preenchimento e tente novamente");
                }

            }
            catch (Exception ex)
            {


                //seta a mensagem de erro
                var strErro = $"Erro ao processar o comando: {ex.Message}";
                //loga o erro e a exception
                log.Error(strErro);
                log.Error(ex);

                //seta a mensagem de retorno
                TempData["Mensagem"] = strErro;


                #region dominios
                ViewBag.Sexos = ListaSexos;
                ViewBag.Racas = ListaRacas;
                ViewBag.Comorbidades = ListaComorbidades;
                ViewBag.SimNao = ListaSimNao;
                ViewBag.Escolaridades = ListaEscolaridade;
                #endregion

                return View(model);
            }



        }

        [HttpGet]
        public ActionResult EditarDemografia(int id)
        {
            //var _usuario = HttpContext.GetOwinContext().Get<ApplicationSignInManager>().UserManager.FindById(User.Identity.GetUserId());

            #region dominios
            ViewBag.Sexos = ListaSexos;
            ViewBag.Racas = ListaRacas;
            ViewBag.Comorbidades = ListaComorbidades;
            ViewBag.SimNao = ListaSimNao;
            ViewBag.Escolaridades = ListaEscolaridade;
            #endregion

            //encontra a entidade no banco.
            var entidade = svcMain.GetById(id);
            if (entidade == null) throw new HttpException(404, "Item não encontrado");

            if ((!User.IsInRole("admin") && !User.IsInRole("supervisor")) && entidade.id_instituicao != _usuario.id_instituicao) throw new HttpException(403, "Não Autorizado");

            var model = entidade.Adapt<DemografiaViewmodel>();

            //arr de comorbidades
            if (!string.IsNullOrEmpty(model.comorbidade)) model.comorbidade_arr = model.comorbidade.Split('|').ToList();


            return View(model);




        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditarDemografia(DemografiaViewmodel model)
        {
            //supervisor não pode gravar nada
            if (User.IsInRole("supervisor")) throw new HttpException(403, "Não autorizado!");

            //var _usuario = HttpContext.GetOwinContext().Get<ApplicationSignInManager>().UserManager.FindById(User.Identity.GetUserId());
            try
            {
                if (ModelState.IsValid)
                {
                    //encontra a entidade no banco.
                    var entidade = svcMain.GetById(model.Id);
                    if (entidade == null) throw new HttpException(404, "Item não encontrado");

                    if (!User.IsInRole("admin") && entidade.id_instituicao != _usuario.id_instituicao) throw new HttpException(403, "Não Autorizado");


                    //Atualiza os valores 
                    entidade.codigocontrole = model.codigocontrole;

                    entidade.date_enrolled = model.date_enrolled;
                    entidade.first_name = model.first_name;
                    entidade.last_name = model.last_name;
                    entidade.cpf_d1 = model.cpf_d1;
                    entidade.telephone_1 = model.telephone_1;
                    entidade.dob = model.dob;
                    entidade.race = model.race;
                    entidade.comorbidade = model.comorbidade;
                    entidade.sex = model.sex;
                    entidade.given_birth = model.given_birth;
                    entidade.num_children = model.num_children ?? 0;
                    entidade.sintomas = model.sintomas;
                    entidade.height = model.height;
                    entidade.weight = model.weight;
                    entidade.comments = model.comments;
                    entidade.telephone_2 = model.telephone_2;
                    entidade.escolaridade = model.escolaridade;
                    //comorbidades
                    entidade.comorbidade = model.comorbidade_arr.ToStringSeparada("|");

                    //verificar se é para trocar o anexo.
                    if (model.patient_document_file != null)
                    {
                        byte[] arr = new byte[model.patient_document_file.ContentLength];
                        model.patient_document_file.InputStream.Read(arr, 0, model.patient_document_file.ContentLength);


                        entidade.patient_document = arr;
                        entidade.patient_document_mime = model.patient_document_file.ContentType;
                        entidade.patient_document_filename = model.patient_document_file.FileName;
                    };

                    svcMain.Update(entidade);
                    log.Info($"FORMULARIO_D0|Modificou o item|{model.Id} ID: {model.Id}|{User.Identity.Name}");

                    TempData["Mensagem"] = "Formulário modificado com sucesso.";
                    //redireciona para a view de listagem 
                    return RedirectToAction("Index");
                }
                else
                {
                    throw new Exception("Erro de validação do modelo. Verifique os dados e tente novamente");
                }


            }
            catch (Exception ex)
            {
                //seta a mensagem de erro
                var strErro = $"Erro ao processar o comando o erro foi: {ex.Message}";
                //loga o erro e a exception
                log.Error(strErro);
                log.Error(ex);

                //seta a mensagem de retorno
                TempData["Mensagem"] = strErro;


                #region dominios
                ViewBag.Sexos = ListaSexos;
                ViewBag.Racas = ListaRacas;
                ViewBag.Comorbidades = ListaComorbidades;
                ViewBag.SimNao = ListaSimNao;
                ViewBag.Escolaridades = ListaEscolaridade;
                #endregion


                return View(model);
            }

        }

        #endregion

        #region D1

        [HttpGet]
        public ActionResult EditarD1(int id)
        {
            //var _usuario = HttpContext.GetOwinContext().Get<ApplicationSignInManager>().UserManager.FindById(User.Identity.GetUserId());
            //encontra a entidade no banco.
            var entidade = svcMain.GetById(id);
            if (entidade == null) throw new HttpException(404, "Item não encontrado");

            //if (!User.IsInRole("admin") && entidade.id_instituicao != _usuario.id_instituicao) throw new HttpException(403, "Não Autorizado");
            if ((!User.IsInRole("admin") && !User.IsInRole("supervisor")) && entidade.id_instituicao != _usuario.id_instituicao) throw new HttpException(403, "Não Autorizado");



            var model = entidade.Adapt<D1Viewmodel>();

            if (!string.IsNullOrEmpty(model.sint_respirat))
            {
                //monta o ARR
                model.sint_respirat_arr = model.sint_respirat.Split('|').ToList();
            }

            #region preparacao            
            ViewBag.Sintomas = ListaSintomas.Where(x => x.Id > 1).ToArray();
            ViewBag.SimNao = ListaSimNao;
            ViewBag.PositivoNegativo = ListaPositivoNegativo;
            #endregion


            return View(model);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditarD1(D1Viewmodel model)
        {

            //supervisor não pode gravar nada
            if (User.IsInRole("supervisor")) throw new HttpException(403, "Não autorizado!");

            //var _usuario = HttpContext.GetOwinContext().Get<ApplicationSignInManager>().UserManager.FindById(User.Identity.GetUserId());

            try
            {


                if (!ModelState.IsValid) throw new Exception("Erro de validação do modelo");


                model.sint_respirat = model.sint_respirat_arr.ToStringSeparada("|");

                //encontra a entidade 
                var entidade = svcMain.GetById(model.Id);
                if (entidade == null) throw new HttpException(404, "Item não encontrado");
                if (!User.IsInRole("admin") && entidade.id_instituicao != _usuario.id_instituicao) throw new HttpException(403, "Não Autorizado");

                //seta o D1 como terimnado para liberação do D7
                entidade.d1 = true;
                entidade.sint_respirat = model.sint_respirat;
                entidade.outros_sint_respir = model.outros_sint_respir;
                entidade.fr_d1 = model.fr_d1;
                entidade.fc_d1 = model.fc_d1;
                entidade.pa_d1 = model.pa_d1;
                entidade.temperatura_d1 = model.temperatura_d1;
                entidade.data_swab_nasal_d1 = model.data_swab_nasal_d1;

                //TRAVA para caso algum espertinho tente burlar a logica de
                //somente admin poder preencher esse campo 
                if (User.IsInRole("admin"))
                {
                    //se for a primeira inclusão envia a notificação (Modelo preenchido, entidade vazia)
                    bool deveEnviarNotificacao = deveEnviarNotificacao = (model.covid_d1.HasValue && !entidade.covid_d1.HasValue);

                    entidade.id_ct_vacinas_d1 = model.id_ct_vacinas_d1;
                    entidade.covid_d1 = model.covid_d1;
                    entidade.data_covid_d1 = model.data_covid_d1;
                    entidade.carga_viral_d1 = model.carga_viral_d1;

                    if (deveEnviarNotificacao) NotificarResultadoExame(TipoFormulario.D1, entidade);

                }


                entidade.pct_saturat_spo2 = model.pct_saturat_spo2;

                entidade.tempo_inicio_medicacao_d1 = model.tempo_inicio_medicacao_d1;
                entidade.tempo_falta_ar_d1 = model.tempo_falta_ar_d1;





                //envia a notificação
                svcMain.Update(entidade);
                log.Info($"FORMULARIO_D1|Criou o item|{model.first_name} {model.last_name}|{model.cpf_d1}|{model.Id} ID: {model.Id}|{User.Identity.Name}");
                log.Info(model);






                //se o teste foi negativo exclui ele do estudo caso não tenha sido excluido ainda.
                if (entidade.covid_d1.HasValue && !entidade.covid_d1.Value && entidade.Id < 10000)
                {
                    log.Info($"FORMULARIO_D1|O Item será desassociado por não ter covid positivo no D1|{model.Id} ID: {model.Id}|{User.Identity.Name}");
                    svcMain.DesassociarEstudo(entidade);
                    TempData["Mensagem"] = "O Formulário foi removido pois o paciente não testou positivo para covid no D1.";
                }
                else
                {
                    //verifica se houve reativação
                    if (entidade.covid_d1.HasValue && entidade.covid_d1.Value && entidade.Id >= 10000)
                    {
                        //verifica antes de reativar, se o usuário está setado como NÃO no D3
                        if (entidade.pacienteretornou_d3.HasValue && !entidade.pacienteretornou_d3.Value)
                        {
                            log.Info($"FORMULARIO_D1|O item: {entidade.Id} - {entidade.first_name} não foi reativado pois está inativo no D3 flg_paciente_retornou = falso");
                        }
                        else
                        {
                            svcMain.AssociarEstudo(entidade);
                            log.Info($"FORMULARIO_D1|O item: {model.Id} - {entidade.first_name} foi reativada com o ID: {entidade.Id}");
                            TempData["Mensagem"] = "Formulário modificado com sucesso. O paciente foi REATIVADO";
                        }


                    }
                    else
                    {
                        TempData["Mensagem"] = "Formulário modificado com sucesso.";
                    }
                }

                //redireciona para a view de listagem 
                return RedirectToAction("Index");

            }
            catch (Exception ex)
            {

                //seta a mensagem de erro
                var strErro = $"Erro ao processar o comando o erro foi: {ex.Message}";
                //loga o erro e a exception
                log.Error(strErro);
                log.Error(ex);

                //seta a mensagem de retorno
                TempData["Mensagem"] = strErro;

                #region preparacao                                
                ViewBag.Sintomas = ListaSintomas.Where(x => x.Id > 1).ToArray();
                ViewBag.SimNao = ListaSimNao;
                ViewBag.PositivoNegativo = ListaPositivoNegativo;
                #endregion

                return (View(model));
            }

        }

        #endregion

        #region D3
        public ActionResult EditarD3(int id)
        {
            //var _usuario = HttpContext.GetOwinContext().Get<ApplicationSignInManager>().UserManager.FindById(User.Identity.GetUserId());

            //encontra a entidade no banco.
            var entidade = svcMain.GetById(id);
            if (entidade == null) throw new HttpException(404, "Item não encontrado");

            //if (!User.IsInRole("admin") && entidade.id_instituicao != _usuario.id_instituicao) throw new HttpException(403, "Não Autorizado");
            if ((!User.IsInRole("admin") && !User.IsInRole("supervisor")) && entidade.id_instituicao != _usuario.id_instituicao) throw new HttpException(403, "Não Autorizado");


            var model = entidade.Adapt<D3Viewmodel>();

            #region preparacao            
            ViewBag.SimNao = ListaSimNao;
            ViewBag.MotivoNaoRetorno = ListaMotivoNaoRetorno;
            #endregion


            return View(model);

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditarD3(D3Viewmodel model)
        {
            //supervisor não pode gravar nada
            if (User.IsInRole("supervisor")) throw new HttpException(403, "Não autorizado!");
            //var _usuario = HttpContext.GetOwinContext().Get<ApplicationSignInManager>().UserManager.FindById(User.Identity.GetUserId());

            try
            {
                if (!ModelState.IsValid) throw new Exception("Erro de validação do modelo");

                //encontra a entidade 
                var entidade = svcMain.GetById(model.Id);
                if (entidade == null) throw new HttpException(404, "Item não encontrado");
                if (!User.IsInRole("admin") && entidade.id_instituicao != _usuario.id_instituicao) throw new HttpException(403, "Não Autorizado");

                //seta o D3 como terimnado para liberação do D8 (somente se ele retornou, se não nem libera o D8 pro paciente)
                entidade.d3 = true;


                entidade.mediadores_d3 = model.mediadores_d3;
                entidade.hg_d3 = model.hg_d3;
                entidade.htc_d3 = model.htc_d3;
                entidade.leuco_d3 = model.leuco_d3;
                entidade.linfo_d3 = model.linfo_d3;
                entidade.neutro_d3 = model.neutro_d3;
                entidade.plaquet_d3 = model.plaquet_d3;
                entidade.pcr_d3 = model.pcr_d3;
                entidade.data_da_coleta_d3 = model.data_da_coleta_d3;

                //campos 27/07
                if (model.dsc_pacienteretornou_d3 == "Desistiu") entidade.motivodesistencia_d3 = model.motivodesistencia_d3;

                //campos 15/06
                entidade.pacienteretornou_d3 = model.pacienteretornou_d3;
                entidade.dsc_pacienteretornou_d3 = model.dsc_pacienteretornou_d3;

                //campos 21/08

                if (User.IsInRole("admin"))
                {
                    entidade.IL_6_d3 = model.IL_6_d3;
                    entidade.IL1_beta_d3 = model.IL1_beta_d3;
                    entidade.IL8_d3 = model.IL8_d3;
                    entidade.TNF_alfa_d3 = model.TNF_alfa_d3;
                    entidade.MCP_1_d3 = model.MCP_1_d3;
                    entidade.IFN_d3 = model.IFN_d3;
                }

                svcMain.Update(entidade);
                log.Info($"FORMULARIO_D3|Criou o item|{model.Id} ID: {entidade.Id}|{entidade.first_name}|{entidade.last_name}|{User.Identity.Name}");
                log.Info(model);

                //verifica se o paciente não retornou 
                if (model.pacienteretornou_d3.HasValue && !model.pacienteretornou_d3.Value)
                {
                    //não retornou, remover ele do estudo 
                    svcMain.DesassociarEstudo(entidade);
                    TempData["Mensagem"] = "Formulário modificado com sucesso. O paciente foi removido do estudo.";
                    log.Info($"FORMULARIO_D3|Item desassociado:{entidade.first_name} - {model.Id} ID: {entidade.Id}|{User.Identity.Name}|{model.pacienteretornou_d3}|{model.dsc_pacienteretornou_d3}");

                }
                else
                {
                    TempData["Mensagem"] = "Formulário modificado com sucesso.";
                }

                //redireciona para a view de listagem 
                return RedirectToAction("Index");

            }
            catch (Exception ex)
            {

                //seta a mensagem de erro
                var strErro = $"Erro ao processar o comando o erro foi: {ex.Message}";
                //loga o erro e a exception
                log.Error(strErro);
                log.Error(ex);

                //seta a mensagem de retorno
                TempData["Mensagem"] = strErro;

                #region preparacao                                
                ViewBag.SimNao = ListaSimNao;
                ViewBag.MotivoNaoRetorno = ListaMotivoNaoRetorno;
                #endregion

                return (View(model));
            }


        }


        #endregion

        #region D8

        [HttpGet]
        public ActionResult EditarD8(int id)
        {
            //var _usuario = HttpContext.GetOwinContext().Get<ApplicationSignInManager>().UserManager.FindById(User.Identity.GetUserId());

            //encontra a entidade no banco.
            var entidade = svcMain.GetById(id);
            if (entidade == null) throw new HttpException(404, "Item não encontrado");

            //if (!User.IsInRole("admin") && entidade.id_instituicao != _usuario.id_instituicao) throw new HttpException(403, "Não Autorizado");
            if ((!User.IsInRole("admin") && !User.IsInRole("supervisor")) && entidade.id_instituicao != _usuario.id_instituicao) throw new HttpException(403, "Não Autorizado");

            var model = entidade.Adapt<D8Viewmodel>();

            if (!string.IsNullOrEmpty(model.sint_respirat_v2)) model.sint_respirat_v2_arr = model.sint_respirat_v2.Split('|').ToList();

            if (!string.IsNullOrEmpty(model.eventosadversos)) model.efeitosadversos_arr = model.eventosadversos.Split('|').ToList();


            #region preparacao            
            ViewBag.Sintomas = ListaSintomas;
            ViewBag.SimNao = ListaSimNao;
            ViewBag.EfeitosAdversos = ListaEfeitosAdversos;
            ViewBag.Niveis = ListaNivel;
            ViewBag.ResultadoInternacao = ListaResultadoInternacao;
            ViewBag.PositivoNegativo = ListaPositivoNegativo;
            #endregion


            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditarD8(D8Viewmodel model)
        {
            //supervisor não pode gravar nada
            if (User.IsInRole("supervisor")) throw new HttpException(403, "Não autorizado!");
            //var _usuario = HttpContext.GetOwinContext().Get<ApplicationSignInManager>().UserManager.FindById(User.Identity.GetUserId());

            try
            {
                if (!ModelState.IsValid) throw new Exception("Erro de validação do modelo");


                model.sint_respirat_v2 = model.sint_respirat_v2_arr.ToStringSeparada("|");
                model.eventosadversos = model.efeitosadversos_arr.ToStringSeparada("|");


                //encontra a entidade 
                var entidade = svcMain.GetById(model.Id);
                if (entidade == null) throw new HttpException(404, "Item não encontrado");
                if (!User.IsInRole("admin") && entidade.id_instituicao != _usuario.id_instituicao) throw new HttpException(403, "Não Autorizado");


                entidade.sint_respirat_v2 = model.sint_respirat_v2;
                entidade.eventosadversos = model.eventosadversos;

                entidade.outros_sint_respir_v2 = model.outros_sint_respir_v2;

                entidade.fr_d7 = model.fr_d7;
                entidade.fc_d7 = model.fc_d7;
                entidade.pa_d7 = model.pa_d7;
                entidade.temperatura_d7 = model.temperatura_d7;
                entidade.data_swab_nasal_d1_v2 = model.data_swab_nasal_d1_v2;

                if (model.interna_d1_v2_desc == "Desistiu") entidade.motivodesistencia_d8 = model.motivodesistencia_d8;

                entidade.data_da_coleta_d8 = model.data_da_coleta_d8;

                if (User.IsInRole("admin"))
                {
                    bool deveEnviarNotificacao = deveEnviarNotificacao = (model.covid_d1_v2.HasValue && !entidade.covid_d1_v2.HasValue);

                    entidade.id_ct_vacinas_d8 = model.id_ct_vacinas_d8;
                    entidade.covid_d1_v2 = model.covid_d1_v2;
                    entidade.data_covid_d1_v2 = model.data_covid_d1_v2;
                    entidade.carga_viral_d1_v2 = model.carga_viral_d1_v2;

                    //campos novos 21/08
                    entidade.IL_6_d8 = model.IL_6_d8;
                    entidade.IL1_beta_d8 = model.IL1_beta_d8;
                    entidade.IL8_d8 = model.IL8_d8;
                    entidade.TNF_alfa_d8 = model.TNF_alfa_d8;
                    entidade.MCP_1_d8 = model.MCP_1_d8;
                    entidade.IFN_d8 = model.IFN_d8;

                    if (deveEnviarNotificacao) NotificarResultadoExame(TipoFormulario.D8, entidade);
                }



                entidade.interna_d1_v2 = model.interna_d1_v2;
                entidade.mediadores_d1_v2 = model.mediadores_d1_v2;
                entidade.hg_d1_v2 = model.hg_d1_v2;
                entidade.htc_d1_v2 = model.htc_d1_v2;
                entidade.leuco_d1_v2 = model.leuco_d1_v2;
                entidade.linfo_d1_v2 = model.linfo_d1_v2;
                entidade.neutro_d1_v2 = model.neutro_d1_v2;
                entidade.plaquet_d1_v2 = model.plaquet_d1_v2;
                entidade.pcr_d1_v2 = model.pcr_d1_v2;


                entidade.outrosmedicamentos = model.outrosmedicamentos;
                entidade.pacientevivo = model.pacientevivo;
                entidade.sint_respirat_v2_dias = model.sint_respirat_v2_dias;
                entidade.pct_saturat_spo2_v2 = model.pct_saturat_spo2_v2;

                entidade.tempo_ventilacao_nao_invasiva_d7 = model.tempo_ventilacao_nao_invasiva_d7;
                entidade.tempo_intubacao_d7 = model.tempo_intubacao_d7;

                entidade.eventosadversosnivel = model.eventosadversosnivel;
                entidade.reacoesadversasnivel = model.reacoesadversasnivel;
                entidade.interna_d1_v2_desc = model.interna_d1_v2_desc;



                //se tiver como NÃO o evento adverso ele zera os dados oriundos dele 
                entidade.teveoutroseventosadversos = model.teveoutroseventosadversos;
                if (model.teveoutroseventosadversos.HasValue && model.teveoutroseventosadversos.Value)
                {
                    entidade.outroseventosadversos = model.outroseventosadversos;
                    entidade.outroseventosadversosnivel = model.outroseventosadversosnivel;
                }
                else
                {
                    entidade.outroseventosadversos = null;
                    entidade.outroseventosadversosnivel = null;
                }

                entidade.tevereacoesadversas = model.tevereacoesadversas;
                if (model.tevereacoesadversas.HasValue && model.tevereacoesadversas.Value)
                {
                    entidade.reacoesadversas = model.reacoesadversas;
                    entidade.reacoesadversasnivel = model.reacoesadversasnivel;
                }
                else
                {
                    entidade.reacoesadversas = null;
                    entidade.reacoesadversasnivel = null;
                }


                entidade.d8 = true;


                entidade.diasesqueceu = model.diasesqueceu;
                entidade.medicamentotodo = model.medicamentotodo;


                svcMain.Update(entidade);
                log.Info($"FORMULARIO_D8|Criou o item|{model.Id}|{entidade.first_name}|{entidade.last_name}| ID: {model.Id}|{User.Identity.Name}");
                log.Info("Item criado D8 fim");
                log.Info(model);


                TempData["Mensagem"] = "Formulário modificado com sucesso.";




                //redireciona para a view de listagem 
                return RedirectToAction("Index");

            }
            catch (Exception ex)
            {

                //seta a mensagem de erro
                var strErro = $"Erro ao processar o comando o erro foi: {ex.Message}";
                //loga o erro e a exception
                log.Error(strErro);
                log.Error(ex);

                //seta a mensagem de retorno
                TempData["Mensagem"] = strErro;

                #region preparacao
                ViewBag.Sintomas = ListaSintomas;
                ViewBag.SimNao = ListaSimNao;
                ViewBag.EfeitosAdversos = ListaEfeitosAdversos;
                ViewBag.Niveis = ListaNivel;
                ViewBag.ResultadoInternacao = ListaResultadoInternacao;
                ViewBag.PositivoNegativo = ListaPositivoNegativo;
                #endregion


                return (View(model));
            }

        }

        #endregion

        #region Resultados

        public JsonResult GetJsonResultados()
        {
            var grupos = svcMain.GetGrupos().ToList();
            var entidades = new List<Formulario>();

            //var _usuario = HttpContext.GetOwinContext().Get<ApplicationSignInManager>().UserManager.FindById(User.Identity.GetUserId());

            if (User.IsInRole("admin") || User.IsInRole("supervisor"))
            {
                entidades = svcMain.GetAll().ToList();
            }
            else
            {
                entidades = svcMain.GetAll().Where(x => x.id_instituicao == _usuario.id_instituicao).ToList();
            }



            var formularios = from f in entidades
                              join gr in grupos on f.Id equals gr.Id into ss
                              from subgrupo in ss.DefaultIfEmpty()
                              select new ResultadoListViewmodel
                              {
                                  Id = f.Id,
                                  first_name = f.first_name,
                                  last_name = f.last_name,
                                  instituicao = f.Instituicao.Nome,
                                  grupo = subgrupo != null ? subgrupo.Grupo : "",
                                  covid_d1 = f.covid_d1.GetValueOrDefault().ToString(),
                                  covid_d1_v2 = f.covid_d1_v2.GetValueOrDefault().ToString()

                              };


            return new JsonResult2 { Data = new { data = formularios } };
        }


        public ActionResult Resultados()
        {
            if (User.IsInRole("supervisor")) throw new HttpException(403, "Acesso negado");

            return View();
        }

        [HttpGet]
        public FileResult GetPatientReport(int Dia, int Id)
        {
            if (Dia != 1 && Dia != 8) throw new HttpException(404, "Item não encontrado");

            var entidade = svcMain.GetById(Id);
            if (entidade == null) throw new HttpException(404, "Não foi possível encontrar o item");


            //var _usuario = HttpContext.GetOwinContext().Get<ApplicationSignInManager>().UserManager.FindById(User.Identity.GetUserId());
            if ((!User.IsInRole("admin") && !User.IsInRole("supervisor")) && entidade.id_instituicao != _usuario.id_instituicao) throw new HttpException(403, "Não Autorizado");


            //carega o template para memória
            var msTemplate = new MemoryStream(System.IO.File.ReadAllBytes(Server.MapPath("~/Templates/template1.docx")));

            //cria o documento a partir do template
            WordDocument objDoc = new WordDocument(msTemplate, FormatType.Docx);

            //atualiza os campos no template
            objDoc.Replace("<<DATA_HOJE>>", DateTime.Now.ToString("dd/MM/yyyy"), false, true);
            objDoc.Replace("<<NOME>>", $"{entidade.first_name} {entidade.last_name}", false, true);
            objDoc.Replace("<<NOME_HOSPITAL>>", entidade.Instituicao.Nome, false, true);

            //Específicos  do dia (D1 ou D8)
            if (Dia == 1)
            {
                if (entidade.covid_d1.HasValue && entidade.covid_d1.Value)
                {
                    objDoc.Replace("<<STATUS_RESULTADO>>", "DETECTÁVEL", false, true);
                    objDoc.Replace("<<DETALHES_RESULTADO>>", "Presença do RNA de Coronavírus SARS-CoV-2 na amostra analisada", false, true);

                }
                else if (entidade.covid_d1.HasValue && !entidade.covid_d1.Value)
                {
                    objDoc.Replace("<<STATUS_RESULTADO>>", "NÃO DETECTÁVEL", false, true);
                    objDoc.Replace("<<DETALHES_RESULTADO>>", "Ausência do RNA de Coronavírus SARS-CoV-2 na amostra analisada", false, true);
                }
                else
                {
                    objDoc.Replace("<<STATUS_RESULTADO>>", "NÃO REALIZADO", false, true);
                    objDoc.Replace("<<DETALHES_RESULTADO>>", "Dado não prenchido.", false, true);
                }

                objDoc.Replace("<<DATA_COLETA_SWAB_NASAL>>", entidade.data_swab_nasal_d1.HasValue ? entidade.data_swab_nasal_d1.Value.ToString("dd/MM/yyyy") : "-", false, true);
                objDoc.Replace("<<DATA_LIBERACAO_RESULTADO>>", entidade.data_covid_d1.HasValue ? entidade.data_covid_d1.Value.ToString("dd/MM/yyyy") : "-", false, true);
                objDoc.Replace("<<ID_CT_VACINAS>>", string.IsNullOrEmpty(entidade.id_ct_vacinas_d1) ? "" : entidade.id_ct_vacinas_d1, false, true);
            }
            else if (Dia == 8)
            {

                if (entidade.covid_d1_v2.HasValue && entidade.covid_d1_v2.Value)
                {
                    objDoc.Replace("<<STATUS_RESULTADO>>", "DETECTÁVEL", false, true);
                    objDoc.Replace("<<DETALHES_RESULTADO>>", "Presença do RNA de Coronavírus SARS-CoV-2 na amostra analisada", false, true);
                }
                else if (entidade.covid_d1_v2.HasValue && !entidade.covid_d1_v2.Value)
                {
                    objDoc.Replace("<<STATUS_RESULTADO>>", "NÃO DETECTÁVEL", false, true);
                    objDoc.Replace("<<DETALHES_RESULTADO>>", "Ausência do RNA de Coronavírus SARS-CoV-2 na amostra analisada", false, true);
                }
                else
                {
                    objDoc.Replace("<<STATUS_RESULTADO>>", "NÃO REALIZADO", false, true);
                    objDoc.Replace("<<DETALHES_RESULTADO>>", "Dado não prenchido", false, true);
                }

                objDoc.Replace("<<DATA_COLETA_SWAB_NASAL>>", entidade.data_swab_nasal_d1_v2.HasValue ? entidade.data_swab_nasal_d1_v2.Value.ToString("dd/MM/yyyy") : "-", false, true);
                objDoc.Replace("<<DATA_LIBERACAO_RESULTADO>>", entidade.data_covid_d1_v2.HasValue ? entidade.data_covid_d1_v2.Value.ToString("dd/MM/yyyy") : "-", false, true);
                objDoc.Replace("<<ID_CT_VACINAS>>", string.IsNullOrEmpty(entidade.id_ct_vacinas_d8) ? "" : entidade.id_ct_vacinas_d8, false, true);
            }

            //converte o DOC para PDF
            DocToPDFConverter objConverter = new DocToPDFConverter();
            PdfDocument objPdf = objConverter.ConvertToPDF(objDoc);

            //Salva o arquivo em um memorystream
            var msSaida = new MemoryStream();
            objPdf.Save(msSaida);

            //fecha os documentos
            objPdf.Close(true);
            objDoc.Close();

            //retorna o arquivo
            return File(msSaida.ToArray(), "application/pdf", $"{entidade.first_name} {entidade.last_name} - Folha de resultado D{Dia}.pdf");

        }


        #endregion

        #region Métodos de apoio
        public void NotificarResultadoExame(TipoFormulario Tipo, Formulario formulario)
        {
            if (Tipo != TipoFormulario.D1 && Tipo != TipoFormulario.D8) throw new Exception("Erro na notificação, formulário inválido");

            //envia um e-mail de notificação com o resultado 

            //carrega o template
            var strConteudo = System.IO.File.ReadAllText(Server.MapPath("~/Templates/notificacaoexame.html"), System.Text.Encoding.GetEncoding(1252));

            //campos comuns 
            strConteudo = strConteudo.Replace("{{ID}}", formulario.Id.ToString());
            strConteudo = strConteudo.Replace("{{Nome}}", $"{formulario.first_name} {formulario.last_name}");
            strConteudo = strConteudo.Replace("{{Tipo}}", Tipo.ToString());


            var strResultado = "";
            var strData = "";

            if (Tipo == TipoFormulario.D1)
            {
                strResultado = !formulario.covid_d1.HasValue ? "Em processamento" : formulario.covid_d1.Value ? "Positivo" : "Negativo";
                strData = formulario.data_covid_d1.HasValue ? formulario.data_covid_d1.Value.ToString("dd/MM/yyyy") : "Aguardando";
            }
            else if (Tipo == TipoFormulario.D8)
            {
                strResultado = !formulario.covid_d1_v2.HasValue ? "Em processamento" : formulario.covid_d1_v2.Value ? "Positivo" : "Negativo";
                strData = formulario.data_covid_d1_v2.HasValue ? formulario.data_covid_d1_v2.Value.ToString("dd/MM/yyyy") : "Aguardando";
            }


            strConteudo = strConteudo.Replace("{{Resultado}}", strResultado);
            strConteudo = strConteudo.Replace("{{Data}}", strData);





            EmailService emailService = new EmailService();

#if DEBUG
            var strDestino = "rguimaraes2006@gmail.com";
#else
            var strDestino = ConfigurationManager.AppSettings["DESTINO_NOTIFICACAO_TESTE"];
#endif

            log.Info($"Notificacao|{User.Identity.Name}|Enviando e-mail|{strConteudo}|PARA:{strDestino}");

            foreach (var item in strDestino.Split(';'))
            {
                emailService.Send(new IdentityMessage
                {
                    Body = strConteudo,
                    Subject = $"Sarita2 - Resultado de Exames - {Tipo}",
                    Destination = item
                });
            }




        }
        #endregion

    }






}