﻿using Microsoft.AspNet.Identity;
using System.Web.Mvc;

public class LogControllerAttribute : ActionFilterAttribute
{
    private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

    public override void OnActionExecuting(ActionExecutingContext filterContext)
    {

        base.OnActionExecuting(filterContext);
        // log.Debug($"START|{filterContext.Controller}|{filterContext.HttpContext.Request.HttpMethod}|{filterContext.HttpContext.Request.Url}");
    }

    public override void OnActionExecuted(ActionExecutedContext filterContext)
    {
        string strUser = "Anonimo";
        if (filterContext.HttpContext.User != null)
        {
            strUser = filterContext.HttpContext.User.Identity.Name;
        }




        base.OnActionExecuted(filterContext);
        log.Debug($"AÇÃO_EXECUTADA|{strUser}|{filterContext.Controller}|{filterContext.HttpContext.Request.HttpMethod}|{filterContext.HttpContext.Request.Url}");
    }

}
