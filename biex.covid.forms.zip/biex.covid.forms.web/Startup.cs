﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(biex.covid.forms.web.Startup))]
namespace biex.covid.forms.web
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
            Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense("MjcwMzMzQDMxMzgyZTMxMmUzMG8zS0xsOHR3aG1KRi9KSlI4UnN2ZitZN2xnQUNWYjQrMTFmYnQwOU9tdEk9");
        }
    }
}
