﻿
namespace biex.utility
{
    public static class Mime
    {

        public static string GetAwesomeFromMime(string mime)
        {
            System.Collections.Generic.Dictionary<string, string> objConfig = new System.Collections.Generic.Dictionary<string, string>();


            // Media
            //image: "fa-file-image-o"
            // audio: "fa-file-audio-o"
            // video: "fa-file-video-o"
            // Documents
            objConfig.Add("image", "fa-file-image-o");
            objConfig.Add("audio", "fa-file-audio-o");
            objConfig.Add("video", "fa-file-video-o");
            objConfig.Add("application/pdf", "fa-file-pdf-o");
            objConfig.Add("application/msword", "fa-file-word-o");
            objConfig.Add("application/vnd.ms-word", "fa-file-word-o");
            objConfig.Add("application/vnd.oasis.opendocument.text", "fa-file-word-o");
            objConfig.Add("application/vnd.openxmlformats-officedocument.wordprocessingml", "fa-file-word-o");
            objConfig.Add("application/vnd.ms-excel", "fa-file-excel-o");
            objConfig.Add("application/vnd.openxmlformats-officedocument.spreadsheetml", "fa-file-excel-o");
            objConfig.Add("application/vnd.oasis.opendocument.spreadsheet", "fa-file-excel-o");
            objConfig.Add("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "fa-file-excel-o");
            objConfig.Add("application/vnd.ms-powerpoint", "fa-file-powerpoint-o");
            objConfig.Add("application/vnd.openxmlformats-officedocument.presentationml", "fa-file-powerpoint-o");
            objConfig.Add("application/vnd.oasis.opendocument.presentation", "fa-file-powerpoint-o");
            objConfig.Add("text/plain", "fa-file-text-o");
            objConfig.Add("text/html", "fa-file-code-o");
            objConfig.Add("application/json", "fa-file-code-o");
            objConfig.Add("application/gzip", "fa-file-archive-o");
            objConfig.Add("application/zip", "fa-file-archive-o");


            return objConfig.ContainsKey(mime) ? objConfig[mime] : "fa-download";




        }
    }
}
