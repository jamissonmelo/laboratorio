﻿namespace biex.utility
{
    public interface IStatusFormulario
    {
        bool? pacienteretornou_d3 { get; set; }
        string dsc_pacienteretornou_d3 { get; set; }
        bool? pacientevivo { get; set; }
        string interna_d1_v2_desc { get; set; }
    }



}


