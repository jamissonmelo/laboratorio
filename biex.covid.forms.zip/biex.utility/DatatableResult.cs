﻿using System;
using System.Collections.Generic;

public class DatatableResult
{
    public IEnumerable<Object> data { get; set; }
}
