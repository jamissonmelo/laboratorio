﻿using System.Collections.Generic;
using System;
using System.Linq;

public static class Extensions
{

    public static string ToStringSeparada<T>(this ICollection<T> Seq, string Separador)
    {
        if (Seq == null || Seq.Count == 0) return string.Empty;

        string strSaida = "";

        foreach (var item in Seq)
        {
            strSaida += Separador + item.ToString();
        }

        //remove o primeiro separador
        return strSaida.Remove(0, Separador.Length);

    }


    public static T GetAttributeFrom<T>(this object instance, string propertyName) where T : Attribute
    {
        var attrType = typeof(T);
        var property = instance.GetType().GetProperty(propertyName);
        return (T)property.GetCustomAttributes(attrType, false).FirstOrDefault();
    }


}



