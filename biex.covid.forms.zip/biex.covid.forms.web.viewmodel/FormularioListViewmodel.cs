﻿using biex.utility;
using System;
using System.ComponentModel.DataAnnotations;

namespace biex.covid.forms.web.viewmodel
{
    public class FormularioListViewmodel : IStatusFormulario
    {
        public int Id { get; set; }

        [Display(Name = "Data em que o paciente deu entrada no estudo")]
        public DateTime date_enrolled { get; set; }

        [Display(Name = "Primeiro Nome")]
        public string first_name { get; set; }

        [Display(Name = "Sobrenome Completo")]
        public string last_name { get; set; }

        public string full_name => $"{first_name} {last_name}";

        [Display(Name = "CPF do Paciente")]
        public string cpf_d1 { get; set; }

        public string grupo { get; set; }

        public bool d1 { get; set; }
        public bool d3 { get; set; }

        public bool d8 { get; set; }

        //Teste covid D8
        public string covid_d1_v2 { get; set; }
        //Teste covid D1
        public string covid_d1 { get; set; }

        public string interna_d1_v2_desc { get; set; }

        public bool? pacientevivo { get; set; }

        public string instituicao { get; set; }

        public bool? pacienteretornou_d3 { get; set; }

        public string dsc_pacienteretornou_d3 { get; set; }


        public string status => Util.ObterStatus(this);
            


    }








}
