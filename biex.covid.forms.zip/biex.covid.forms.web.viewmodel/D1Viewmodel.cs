﻿using biex.covid.forms.domain.entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace biex.covid.forms.web.viewmodel
{
    #region D1
    public class D1Viewmodel
    {
        [Display(Name = "Identificação do estudo")]
        public int Id { get; set; }


        [Display(Name = "Paciente apresenta sintomas?")]
        public string sint_respirat { get; set; }


        public D1Viewmodel()
        {
            sint_respirat_arr = new List<string>();
        }
        public List<string> sint_respirat_arr { get; set; }


        [Display(Name = "Outros sintomas?")]
        public string outros_sint_respir { get; set; }

        [Display(Name = "FR")]
        //  [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public int? fr_d1 { get; set; }

        [Display(Name = "FC")]
        //[Required(ErrorMessage = "O campo {0} é obrigatório")]
        public int? fc_d1 { get; set; }

        [Display(Name = "PA(xx/xx)")]
        //[Required(ErrorMessage = "O campo {0} é obrigatório")]
        public string pa_d1 { get; set; }


        [Display(Name = "Temperatura (ex: 37,5)")]
        public decimal? temperatura_d1 { get; set; }

        [Display(Name = "Data coleta swab nasal?")]
        public DateTime? data_swab_nasal_d1 { get; set; }

        [Display(Name = "Qual o resultado da PCR para COVID-19?")]
        public bool? covid_d1 { get; set; }

        public string covid_d1_desc => (!this.covid_d1.HasValue) ? "Campo exclusivo" : this.covid_d1.Value ? "Positivo" : "Negativo";


        [Display(Name = "Data da liberação do resultado do exame")]
        public DateTime? data_covid_d1 { get; set; }

        public string data_covid_d1_desc => this.data_covid_d1.HasValue ? this.data_covid_d1.Value.ToString("dd/MM/yyyy") : "";

        [Display(Name = "Qual a carga viral?")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:0.0000}")]
        public decimal? carga_viral_d1 { get; set; }



        [Display(Name = "Saturação de Oxigênio (SpO2, %)")]
        [Range(0, 100, ErrorMessage = "Informe o valor de 0 até 100")]
        // [Required(ErrorMessage = "O campo {0} é obrigatório")]
        //[Required(ErrorMessage ="O campo é obrigatório")]
        public int? pct_saturat_spo2 { get; set; }



        [Display(Name = "Tempo do início da doença ao início da medicação")]

        public int? tempo_inicio_medicacao_d1 { get; set; }

        [Display(Name = "Tempo desde o início da doença até a falta de ar")]
        // [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public int? tempo_falta_ar_d1 { get; set; }


        [Display(Name = "ID CT VACINAS")]
        public string id_ct_vacinas_d1 { get; set; }



        public string first_name { get; set; }
        public string last_name { get; set; }
        public string cpf_d1 { get; set; }

        public override string ToString()
        {
            string strRet = $"D1Viewmodel|{Id}|{cpf_d1}|{first_name}|{last_name}|{covid_d1}";
            return strRet;

        }

    }

    #endregion

}
