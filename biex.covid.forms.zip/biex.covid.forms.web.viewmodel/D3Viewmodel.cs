﻿using System;
using System.ComponentModel.DataAnnotations;

namespace biex.covid.forms.web.viewmodel
{

    public class D3Viewmodel
    {
        [Display(Name = "Identificação do estudo")]
        public int Id { get; set; }


        [Display(Name = "O paciente retornou para receber o medicamento?")]
        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public bool? pacienteretornou_d3 { get; set; }

        [Display(Name = "Qual o motivo?")]
        public string dsc_pacienteretornou_d3 { get; set; }





        [Display(Name = "Foi realizada coleta de sangue para análise de mediadores plasmáticos? ")]
        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public bool mediadores_d3 { get; set; }


        [Display(Name = "Hemoglobina (g/dL) ")]
        //[Required(ErrorMessage = "O campo {0} é obrigatório")]
        public decimal? hg_d3 { get; set; }

        [Display(Name = "Hematócrito (%)")]
        // [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public int? htc_d3 { get; set; }

        [Display(Name = "Leucócitos (Glób / mcL)")]
        // [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public int? leuco_d3 { get; set; }

        [Display(Name = "Linfócitos (10^9 por L)")]
        //   [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public int? linfo_d3 { get; set; }

        [Display(Name = "Neutrófilos (células/mm3)")]
        // [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public int? neutro_d3 { get; set; }

        [Display(Name = "Plaquetas (/microl)")]
        //  [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public string plaquet_d3 { get; set; }

        [Display(Name = "Proteína C-reativa (mg/L) ")]
        //  [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public string pcr_d3 { get; set; }

        [Display(Name = "Data da coleta do sangue")]
        public DateTime? data_da_coleta_d3 { get; set; }


        public string first_name { get; set; }
        public string last_name { get; set; }
        public string cpf_d1 { get; set; }

        public override string ToString()
        {
            string strRet = $"D3Viewmodel|{Id}|{cpf_d1}|{first_name}|{last_name}|{pacienteretornou_d3}|{dsc_pacienteretornou_d3}";
            return strRet;
        }

        [Display(Name = "Em caso de desistência, informe o motivo")]
        public string motivodesistencia_d3 { get; set; }


        //campos novos 21/08
        [Display(Name = "Resultado de IL-6")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:0.0}")]
        public decimal? IL_6_d3 { get; set; }

        [Display(Name = "Resultado de IL1-beta")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:0.0}")]
        public decimal? IL1_beta_d3 { get; set; }

        [Display(Name = "Resultado de IL-8")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:0.0}")]
        public decimal? IL8_d3 { get; set; }

        [Display(Name = "Resultado de TNF-alfa")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:0.0}")]
        public decimal? TNF_alfa_d3 { get; set; }

        [Display(Name = "Resultado de MCP-1")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:0.0}")]
        public decimal? MCP_1_d3 { get; set; }

        [Display(Name = "Resultado de IFN")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:0.0}")]
        public decimal? IFN_d3 { get; set; }



    }

}
