﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace biex.covid.forms.web.viewmodel
{
    public class DashViewmodel
    {
        public int id_instituicao { get; set; }


        public DadosProgressoViewmodel DadosProgresso { get; set; }


        public DashViewmodel()
        {
            this.DadosProgresso = new DadosProgressoViewmodel();
        }






        public class DadosProgressoViewmodel
        {
            public int GrupoA { get; set; }
            public int GrupoB { get; set; }

            public int TotalVagas { get; set; }

            public string PercentualA => ((double)GrupoA / TotalVagas).ToString("0%");
            public string PerceutualB => ((double)GrupoB / TotalVagas).ToString("0%");

            public int Livres => TotalVagas - (GrupoA + GrupoB);
            public string PercentualLive => ((double)Livres / TotalVagas).ToString("0%");

        }
    }
}
