﻿using System.ComponentModel.DataAnnotations;

namespace biex.covid.forms.web.Models
{
    public class ForgotPasswordViewModel
    {
        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }
    }
}
