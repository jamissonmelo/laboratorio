﻿namespace biex.covid.forms.web.Models
{



    public class FactorViewModel
    {
        public string Purpose { get; set; }
    }


}