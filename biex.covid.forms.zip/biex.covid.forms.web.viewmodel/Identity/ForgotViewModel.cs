﻿using System.ComponentModel.DataAnnotations;

namespace biex.covid.forms.web.Models
{
    public class ForgotViewModel
    {
        [Required]
        [Display(Name = "Email")]
        public string Email { get; set; }
    }
}
