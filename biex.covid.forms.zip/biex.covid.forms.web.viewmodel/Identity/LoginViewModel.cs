﻿using System.ComponentModel.DataAnnotations;

namespace biex.covid.forms.web.Models
{
    public class LoginViewModel
    {
        [Required]
        [Display(Name = "Email")]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Senha")]
        public string Password { get; set; }

        [Display(Name = "Gravar os dados?")]
        public bool RememberMe { get; set; }
    }
}
