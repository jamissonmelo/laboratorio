﻿using biex.covid.forms.domain.entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace biex.covid.forms.web.viewmodel
{
    public class D8Viewmodel
    {
        public D8Viewmodel()
        {
            sint_respirat_v2_arr = new List<string>();
            efeitosadversos_arr = new List<string>();

        }
        [Display(Name = "Identificação do estudo")]
        public int Id { get; set; }

        [Display(Name = "O paciente está vivo?")]
        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public bool? pacientevivo { get; set; }


        [Display(Name = "Paciente apresenta sintomas?")]
        public string sint_respirat_v2 { get; set; }

        public List<string> sint_respirat_v2_arr { get; set; }


        public string sint_respirat_v2_dias { get; set; }



        [Display(Name = "Outros sintomas?")]
        public string outros_sint_respir_v2 { get; set; }

        [Display(Name = "FR")]
        public int? fr_d7 { get; set; }

        [Display(Name = "FC")]
        public int? fc_d7 { get; set; }

        [Display(Name = "PA(xx/xx)")]
        [MaxLength(8, ErrorMessage = "O campo pode ter no máximo {1} caracteres")]
        public string pa_d7 { get; set; }

        [Display(Name = "Temperatura (ex: 37,5)")]
        public decimal? temperatura_d7 { get; set; }


        [Display(Name = "Data coleta swab nasal?")]
        public DateTime? data_swab_nasal_d1_v2 { get; set; }

        [Display(Name = "Qual o resultado da PCR para COVID-19?")]
        public bool? covid_d1_v2 { get; set; }

        public string covid_d1_v2_desc => (!this.covid_d1_v2.HasValue) ? "Campo exclusivo" : this.covid_d1_v2.Value ? "Positivo" : "Negativo";


        [Display(Name = "Data da liberação do resultado do exame")]
        public DateTime? data_covid_d1_v2 { get; set; }

        public string data_covid_d1_v2_desc => this.data_covid_d1_v2.HasValue ? this.data_covid_d1_v2.Value.ToString("dd/MM/yyyy") : "";



        [Display(Name = "Qual a carga viral?")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:0.0000}")]
        public decimal? carga_viral_d1_v2 { get; set; }

        [Display(Name = "Saturação de Oxigênio (SpO2, %)")]
        [Range(0, 100, ErrorMessage = "Informe o valor de 0 até 100")]


        public int? pct_saturat_spo2_v2 { get; set; }


        [Display(Name = "Tempo desde o início da doença até oxigenioterapia/Ventilação Não invasiva")]
        public int? tempo_ventilacao_nao_invasiva_d7 { get; set; }

        [Display(Name = "Tempo desde o início da doença falência respiratória aguda e intubação traqueal e ventilação invasiva")]
        public int? tempo_intubacao_d7 { get; set; }

        [Display(Name = "Paciente internou no hospital?")]
        public bool interna_d1_v2 { get; set; }

        public string interna_d1_v2_desc { get; set; }//o paciente internou? Se sim.... se não...

        [Display(Name = "Foi realizada coleta de sangue para análise de mediadores plasmáticos ? ")]
        public bool mediadores_d1_v2 { get; set; }//foi realizada coleta..

        [Display(Name = "Paciente fez uso de outros medicamentos? Se sim, quais?")]
        [MaxLength(100, ErrorMessage = "O campo pode ter no máximo {1} caracteres")]
        public string outrosmedicamentos { get; set; }

        [Display(Name = "Hemoglobina (g/dL) ")]

        public decimal? hg_d1_v2 { get; set; }

        [Display(Name = "Hematócrito (%)")]

        public int? htc_d1_v2 { get; set; }

        [Display(Name = "Leucócitos (Glób / mcL)")]
        public int? leuco_d1_v2 { get; set; }

        [Display(Name = "Linfócitos (10^9 por L)")]
        public int? linfo_d1_v2 { get; set; }

        [Display(Name = "Neutrófilos (células/mm3)")]
        public int? neutro_d1_v2 { get; set; }

        [Display(Name = "Plaquetas (/microl)")]
        [MaxLength(100, ErrorMessage = "O campo pode ter no máximo {1} caracteres")]
        public string plaquet_d1_v2 { get; set; }

        [Display(Name = "Proteína C-reativa (mg/L) ")]
        public string pcr_d1_v2 { get; set; }

        [Display(Name = "Reações adversas ao medicamento?")]
        public string eventosadversos { get; set; }


        //guardar  o JSON das seleções dos eventos adversos
        public string eventosadversosnivel { get; set; }


        #region EVENTOS ADVERSOS

        [Display(Name = "Outras reações adversas ao medicamento?")]
        public bool? teveoutroseventosadversos { get; set; }


        [Display(Name = "Quais eventos?")]
        public string outroseventosadversos { get; set; }


        public string outroseventosadversosnivel { get; set; }



        public List<string> efeitosadversos_arr { get; set; }


        #endregion

        #region REAÇÕES ADVERSAS

        [Display(Name = "Eventos adversos?")]
        public bool? tevereacoesadversas { get; set; }

        [Display(Name = "Descreva")]
        [MaxLength(100, ErrorMessage = "O campo pode ter no máximo {1} caracteres")]
        public string reacoesadversas { get; set; }

        public string reacoesadversasnivel { get; set; }

        #endregion



        #region medicamento_todos_os_dias

        [Display(Name = "Paciente tomou o remédio todos os dias?")]
        public bool? medicamentotodo { get; set; }

        [Display(Name = "Quantos dias esqueceu de tomar?")]
        [Range(0, 10, ErrorMessage = "Informe um valor entre {1} e {2}")]
        public int? diasesqueceu { get; set; }

        #endregion

        [Display(Name = "Data da coleta do sangue")]
        public DateTime? data_da_coleta_d8 { get; set; }


        [Display(Name = "ID CT VACINAS")]
        public string id_ct_vacinas_d8 { get; set; }



        public string first_name { get; set; }
        public string last_name { get; set; }
        public string cpf_d1 { get; set; }

        [Display(Name = "Em caso de desistência, informe o motivo")]
        public string motivodesistencia_d8 { get; set; }





        //campos novos 21/08
        [Display(Name = "Resultado de IL-6")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:0.0}")]
        public decimal? IL_6_d8 { get; set; }

        [Display(Name = "Resultado de IL1-beta")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:0.0}")]
        public decimal? IL1_beta_d8 { get; set; }

        [Display(Name = "Resultado de IL-8")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:0.0}")]
        public decimal? IL8_d8 { get; set; }

        [Display(Name = "Resultado de TNF-alfa")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:0.0}")]
        public decimal? TNF_alfa_d8 { get; set; }

        [Display(Name = "Resultado de MCP-1")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:0.0}")]
        public decimal? MCP_1_d8 { get; set; }

        [Display(Name = "Resultado de IFN")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:0.0}")]
        public decimal? IFN_d8 { get; set; }







        public override string ToString()
        {
            string strRet = $"D8Viewmodel|{Id}|{cpf_d1}|{first_name}|{last_name}|{pacientevivo}|{covid_d1_v2}";
            return strRet;

        }


    }















}


