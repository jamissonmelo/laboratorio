﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace biex.covid.forms.web.viewmodel
{
    public enum TipoFormulario
    {
        Demografia, D1, D3, D8
    }
}
