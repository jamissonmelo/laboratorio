﻿using System;
using System.ComponentModel.DataAnnotations;

namespace biex.covid.forms.web.viewmodel
{
    public class UsuarioViewmodel
    {
        public string Id { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        [Display(Name = "Instituição")]
        public int id_instituicao { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        [MaxLength(100, ErrorMessage = "O campo só pode ter até {1} caracteres")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        [MaxLength(100, ErrorMessage = "O campo só pode ter até {1} caracteres")]
        [DataType(DataType.EmailAddress, ErrorMessage = "Informe um e-mail válido")]
        public string Email { get; set; }

        public bool Administrador { get; set; }

        public bool Supervisor { get; set; }

        public string Instituicao { get; set; }

        public bool Ativo { get; set; }

        public string StatusDesc => Ativo ? "Ativo" : "Inativo";


        [Display(Name = "Permissão do usuário")]
        public int id_permissao { get; set; }


    }
}
