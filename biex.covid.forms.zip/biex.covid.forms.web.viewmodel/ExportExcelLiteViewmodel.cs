﻿using biex.utility;
using System;
using System.ComponentModel;


namespace biex.covid.forms.web.viewmodel
{
    public class ExportExcelLiteViewmodel : IStatusFormulario
    {
        [DisplayName("POSICAO")]
        public int Id { get; set; }

        [DisplayName("TIPO")]
        public string Grupo { get; set; }

        public string Hospital { get; set; }

        [DisplayName("SIGLA")]
        public InstituicaoViewmodel Instituicao { get; set; }

        [DisplayName("CIDADE")]
        public string Cidade { get; set; }

        [DisplayName("ESTADO")]
        public string Estado { get; set; }

        [DisplayName("CPF")]
        public string cpf_d1 { get; set; }

        [DisplayName("NOME")]
        public string fullName => $"{first_name} {last_name}";

        [DisplayName("COVID (1º dia)")]
        public bool? covid_d1 { get; set; }

        [DisplayName("CARGA VIRAL (1º dia)")]
        public decimal? carga_viral_d1 { get; set; }


        [DisplayName("COVID (8º dia)")]
        public bool? covid_d1_v2 { get; set; }

        [DisplayName("CARGA VIRAL (8º dia)")]
        public decimal? carga_viral_d1_v2 { get; set; }

        [DisplayName("STATUS")]
        public string status { get; set; }

        [DisplayName("MOTIVO DA DESISTÊNCIA")]
        public string motivo { get; set; }

        [DisplayName("OBSERVAÇÃO")]
        public string observacoes { get; set; }

        [DisplayName("DATA DE CADASTRO")]
        public DateTime date_enrolled { get; set; }

        [DisplayName("DATA DA ÚLTIMA ALTERAÇÃO")]
        public string dataalteracao => DateTime.Now.ToString("dd/MM/yyyy");



        [DisplayName("O paciente retornou para receber o medicamento?")]
        public bool? pacienteretornou_d3 { get; set; }



        [DisplayName("Data da liberação do resultado do exame D1")]
        public DateTime? data_covid_d1 { get; set; }


        [DisplayName("Telefone celular do paciente")]
        public string telephone_1 { get; set; }


        public string first_name { get; set; }
        public string last_name { get; set; }

        public string dsc_pacienteretornou_d3 { get; set; }
        public bool? pacientevivo { get; set; }
        public string interna_d1_v2_desc { get; set; }
    }










}
