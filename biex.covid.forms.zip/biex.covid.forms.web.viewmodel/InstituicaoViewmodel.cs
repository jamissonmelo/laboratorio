﻿using System.ComponentModel.DataAnnotations;

namespace biex.covid.forms.web.viewmodel
{
    public class InstituicaoViewmodel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        [MaxLength(30, ErrorMessage = "O campo só pode ter até {1} caracteres")]
        public string Nome { get; set; }

        public override string ToString()
        {
            return this.Nome;
        }

    }
}
