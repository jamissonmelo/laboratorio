﻿using System.ComponentModel.DataAnnotations;

namespace biex.covid.forms.web.viewmodel
{
    public class ResultadoListViewmodel
    {
        public int Id { get; set; }

        [Display(Name = "Primeiro Nome")]
        public string first_name { get; set; }

        [Display(Name = "Sobrenome Completo")]
        public string last_name { get; set; }

        public string full_name => $"{first_name} {last_name}";

        [Display(Name = "CPF do Paciente")]
        public string cpf_d1 { get; set; }

        public string grupo { get; set; }

        public string instituicao { get; set; }

        public string covid_d1_v2 { get; set; }
        //Teste covid D1
        public string covid_d1 { get; set; }



    }


}
