﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace biex.covid.forms.web.viewmodel
{
    public class ExportExcelViewmodel
    {

        [DisplayName("Identificação do estudo")]
        public int Id { get; set; }


        [DisplayName("Código de barras de controle")]
        public string codigocontrole { get; set; }


        #region demografia




        [DisplayName("Data em que o paciente deu entrada no estudo")]

        public DateTime date_enrolled { get; set; }


        [DisplayName("Primeiro nome")]
        public string first_name { get; set; }

        [DisplayName("Sobrenome completo")]
        public string last_name { get; set; }

        [DisplayName("CPF do paciente")]
        public string cpf_d1 { get; set; }

        [DisplayName("Telefone Celular do paciente")]

        public string telephone_1 { get; set; }

        [DisplayName("Telefone Fixo do paciente")]
        public string telephone_2 { get; set; }


        [DisplayName("Data de nascimento")]
        public DateTime dob { get; set; }


        [DisplayName("Raça")]
        public string race { get; set; }

        [DisplayName("Escolaridade")]
        public string escolaridade { get; set; }

        [DisplayName("Paciente apresenta comorbidade?")]
        public string comorbidade { get; set; }


        [DisplayName("Sexo")]

        public string sex { get; set; }


        [DisplayName("A paciente já engravidou alguma vez?")]

        public bool given_birth { get; set; }

        [DisplayName("Caso sim, quantas vezes?")]

        public int? num_children { get; set; }

        [DisplayName("Há quanto tempo (dias) o paciente apresenta sintomas?")]

        public string sintomas { get; set; }

        [DisplayName("Altura (cm)")]
        public int height { get; set; }

        [DisplayName("Peso (Quilos)")]
        public int weight { get; set; }

        public string IMC => ((weight * 10000) / (Math.Pow(height, 2))).ToString("##.##");
        //var resp = (peso * 10000) / (altura * altura);

        [DisplayName("Paciente fez uso de medicação prévia? Se sim, por favor transcreva na caixa de comentários")]
        public string comments { get; set; }

        #endregion


        public string Grupo { get; set; }

        [DisplayName("Instituição")]
        public InstituicaoViewmodel Instituicao { get; set; }

        public string id_usuario { get; set; }

        [DisplayName("Paciente apresenta sintomas D1?")]
        public string sint_respirat { get; set; }

        [DisplayName("Outros sintomas?")]
        public string outros_sint_respir { get; set; }

        [DisplayName("FR")]
        public int? fr_d1 { get; set; }

        [DisplayName("FC")]
        public int? fc_d1 { get; set; }

        [DisplayName("PA(xx/xx)")]
        public string pa_d1 { get; set; }


        [DisplayName("Temperatura")]
        public decimal? temperatura_d1 { get; set; }

        [DisplayName("Data Coleta Swab Nasal D1?")]
        public DateTime? data_swab_nasal_d1 { get; set; }

        [DisplayName("Qual o resultado da PCR para COVID-19 D1?")]
        public bool? covid_d1 { get; set; }


        [DisplayName("Data da liberação do resultado do exame D1")]
        public DateTime? data_covid_d1 { get; set; }



        [DisplayName("Qual a carga viral?")]
        public decimal? carga_viral_d1 { get; set; }



        [DisplayName("Saturação de Oxigênio (SpO2, %)")]
        public int? pct_saturat_spo2 { get; set; }



        [DisplayName("Tempo do início da doença ao início da medicação")]
        public int? tempo_inicio_medicacao_d1 { get; set; }

        [DisplayName("Tempo desde o início da doença até a falta de ar")]

        public int? tempo_falta_ar_d1 { get; set; }


        [DisplayName("ID CT VACINAS D1")]
        public string id_ct_vacinas_d1 { get; set; }


        //D3

        [DisplayName("O paciente retornou para receber o medicamento?")]
        public bool? pacienteretornou_d3 { get; set; }
        [DisplayName("Qual o motivo?")]
        public string dsc_pacienteretornou_d3 { get; set; }



        [DisplayName("Data da coleta do sangue D3")]
        public DateTime? data_da_coleta_d3 { get; set; }

        [DisplayName("Foi realizada coleta de sangue para análise de mediadores plasmáticos? ")]
        public bool mediadores_d3 { get; set; }

        [DisplayName("Hemoglobina (g/dL) ")]
        //
        public decimal? hg_d3 { get; set; }

        [DisplayName("Hematócrito (%)")]
        // 
        public int? htc_d3 { get; set; }

        [DisplayName("Leucócitos (Glób / mcL)")]
        // 
        public int? leuco_d3 { get; set; }

        [DisplayName("Linfócitos (10^9 por L)")]
        //   
        public int? linfo_d3 { get; set; }

        [DisplayName("Neutrófilos (células/mm3)")]
        // 
        public int? neutro_d3 { get; set; }

        [DisplayName("Plaquetas (/microl)")]
        //  
        public string plaquet_d3 { get; set; }

        [DisplayName("Proteína C-reativa (mg/L) ")]
        //  
        public string pcr_d3 { get; set; }

        [DisplayName("O paciente está vivo?")]

        public bool? pacientevivo { get; set; }


        [DisplayName("Paciente apresenta sintomas D8?")]
        public string sint_respirat_v2 { get; set; }


        [DisplayName("Paciente apresenta sintomas? (dias)")]
        public string sint_respirat_v2_dias { get; set; }



        [DisplayName("Outros sintomas?")]
        public string outros_sint_respir_v2 { get; set; }

        [DisplayName("FR")]
        public int? fr_d7 { get; set; }

        [DisplayName("FC")]
        public int? fc_d7 { get; set; }

        [DisplayName("PA(xx/xx)")]
        public string pa_d7 { get; set; }

        [DisplayName("Temperatura")]
        public decimal? temperatura_d7 { get; set; }


        [DisplayName("Data Coleta Swab Nasal D8")]
        public DateTime? data_swab_nasal_d1_v2 { get; set; }


        [DisplayName("Qual o resultado da PCR para COVID-19 D8?")]
        public bool? covid_d1_v2 { get; set; }


        [DisplayName("Data da liberação do resultado do exame D8")]
        public DateTime? data_covid_d1_v2 { get; set; }


        [DisplayName("Qual a carga viral D8?")]
        public decimal? carga_viral_d1_v2 { get; set; }

        [DisplayName("Data da coleta de sangue D8")]
        public DateTime? data_da_coleta_d8 { get; set; }


        [DisplayName("Saturação de Oxigênio (SpO2, %)")]
        public int? pct_saturat_spo2_v2 { get; set; }


        [DisplayName("Tempo desde o início da doença até oxigenioterapia/Ventilação Não invasiva")]
        public int? tempo_ventilacao_nao_invasiva_d7 { get; set; }

        [DisplayName("Tempo desde o início da doença falência respiratória aguda e intubação traqueal e ventilação invasiva")]
        public int? tempo_intubacao_d7 { get; set; }

        [DisplayName("Paciente internou no hospital?")]
        public bool interna_d1_v2 { get; set; }



        public string interna_d1_v2_desc { get; set; }//o paciente internou? Se sim.... se não...

        [DisplayName("Foi realizada coleta de sangue para análise de mediadores plasmáticos ? ")]
        public bool mediadores_d1_v2 { get; set; }//foi realizada coleta..

        [DisplayName("Paciente fez uso de outros medicamentos? Se sim, quais?")]

        public string outrosmedicamentos { get; set; }

        [DisplayName("Hemoglobina (g/dL) ")]

        public decimal? hg_d1_v2 { get; set; }

        [DisplayName("Hematócrito (%)")]

        public int? htc_d1_v2 { get; set; }

        [DisplayName("Leucócitos (Glób / mcL)")]
        public int? leuco_d1_v2 { get; set; }

        [DisplayName("Linfócitos (10^9 por L)")]
        public int? linfo_d1_v2 { get; set; }

        [DisplayName("Neutrófilos (células/mm3)")]
        public int? neutro_d1_v2 { get; set; }

        [DisplayName("Plaquetas (/microl)")]

        public string plaquet_d1_v2 { get; set; }

        [DisplayName("Proteína C-reativa (mg/L) ")]
        public string pcr_d1_v2 { get; set; }

        [DisplayName("Reações adversas ao medicamento?")]
        public string eventosadversos { get; set; }


        //guardar  o JSON das seleções dos eventos adversos
        public string eventosadversosnivel { get; set; }


        #region EVENTOS ADVERSOS

        [DisplayName("Outras reações adversas ao medicamento?")]
        public bool? teveoutroseventosadversos { get; set; }


        [DisplayName("Quais eventos?")]
        public string outroseventosadversos { get; set; }


        [DisplayName("Nívels de reações adversas?")]
        public string outroseventosadversosnivel { get; set; }

        #endregion

        #region REAÇÕES ADVERSAS

        [DisplayName("Eventos adversos?")]
        public bool? tevereacoesadversas { get; set; }

        [DisplayName("Descreva")]

        public string reacoesadversas { get; set; }

        [DisplayName("Nível Eventos Adversos")]
        public string reacoesadversasnivel { get; set; }

        #endregion




        [DisplayName("Paciente tomou o remédio todos os dias?")]
        public bool? medicamentotodo { get; set; }

        [DisplayName("Quantos dias esqueceu de tomar?")]
        public int? diasesqueceu { get; set; }

        [DisplayName("ID CT VACINAS D8")]
        public string id_ct_vacinas_d8 { get; set; }


        [DisplayName("Em caso de desistência, informe o motivo - D3")]
        public string motivodesistencia_d3 { get; set; }


        [DisplayName("Em caso de desistência, informe o motivo - D8")]
        public string motivodesistencia_d8 { get; set; }



        //campos novos 21/08
        [DisplayName( "Resultado de IL-6 D3")]
        public decimal? IL_6_d3 { get; set; }

        [DisplayName("Resultado de IL1-beta D3")]
        public decimal? IL1_beta_d3 { get; set; }

        [DisplayName("Resultado de IL-8 D3")]
        public decimal? IL8_d3 { get; set; }

        [DisplayName("Resultado de TNF-alfa D3")]
        public decimal? TNF_alfa_d3 { get; set; }

        [DisplayName("Resultado de MCP-1 D3")]
        public decimal? MCP_1_d3 { get; set; }

        [DisplayName("Resultado de IFN D3")]
        public decimal? IFN_d3 { get; set; }


        //campos novos 21/08
        [DisplayName( "Resultado de IL-6 D8")]
        public decimal? IL_6_d8 { get; set; }

        [DisplayName("Resultado de IL1-beta D8")]
        public decimal? IL1_beta_d8 { get; set; }

        [DisplayName("Resultado de IL-8 D8")]
        public decimal? IL8_d8 { get; set; }

        [DisplayName("Resultado de TNF-alfa D8")]
        public decimal? TNF_alfa_d8 { get; set; }

        [DisplayName("Resultado de MCP-1 D8")]
        public decimal? MCP_1_d8 { get; set; }

        [DisplayName("Resultado de IFN D8")]
        public decimal? IFN_d8 { get; set; }






















    }










}
