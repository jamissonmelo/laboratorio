﻿using biex.covid.forms.domain.entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.CompilerServices;
using System.Web;
using System.Web.Mvc;

namespace biex.covid.forms.web.viewmodel
{
    public partial class DemografiaViewmodel
    {
        public DemografiaViewmodel()
        {
            comorbidade_arr = new List<string>();
        }

        #region Demografia

        [Display(Name = "Identificação do estudo")]
        public int Id { get; set; }


        [Display(Name = "Código de barras de controle")]
        [Remote("ControleValido", "Formulario",
            HttpMethod = "POST", AdditionalFields = "Id",
            ErrorMessage = "O código está em uso em outro paciente.")]
        public int? codigocontrole { get; set; }

        [Display(Name = "Data em que o paciente deu entrada no estudo")]
        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public DateTime date_enrolled { get; set; }



        public HttpPostedFileBase patient_document_file { get; set; }

        public string patient_document_mime { get; set; }
        public string patient_document_filename { get; set; }

        [Display(Name = "Upload do TCLE do paciente (somente a página onde contém a assinatura)")]
        public byte[] patient_document { get; set; }

        [Display(Name = "Primeiro nome")]
        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        [MaxLength(50, ErrorMessage = "O campo pode ter no máximo {1} caracteres")]
        public string first_name { get; set; }

        [Display(Name = "Sobrenome completo")]
        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        [MaxLength(100, ErrorMessage = "O campo pode ter no máximo {1} caracteres")]
        public string last_name { get; set; }

        [Display(Name = "CPF do paciente")]
        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        [MaxLength(16, ErrorMessage = "O campo pode ter no máximo {1} caracteres")]
        [Remote("CPFValido", "Formulario",
            HttpMethod = "POST", AdditionalFields = "Id"
            //ErrorMessage = "O CPF está em uso em outro paciente."
            )]
        public string cpf_d1 { get; set; }

        [Display(Name = "Telefone celular do paciente")]
        [MaxLength(100, ErrorMessage = "O campo pode ter no máximo {1} caracteres")]
        public string telephone_1 { get; set; }

        [Display(Name = "Telefone fixo do paciente")]
        [MaxLength(100, ErrorMessage = "O campo pode ter no máximo {1} caracteres")]
        public string telephone_2 { get; set; }


        [Display(Name = "Data de nascimento")]
        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        [Remote("MaiorDeIdade", "Formulario",
            HttpMethod = "POST",
            ErrorMessage = "O paciente precisa ter mais de 18 anos.")]
        public DateTime dob { get; set; }


        [Display(Name = "Raça")]
        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public string race { get; set; }

        [Display(Name = "Escolaridade")]
        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public string escolaridade { get; set; }

        [Display(Name = "Paciente apresenta comorbidade?")]
        public string comorbidade { get; set; }


        [Display(Name = "Paciente apresenta comorbidade?")]
        [Required(ErrorMessage = "Informe se o paciente apresenta alguma comorbidade")]
        public List<string> comorbidade_arr { get; set; }



        [Display(Name = "Sexo")]
        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public string sex { get; set; }


        [Display(Name = "A paciente já engravidou alguma vez?")]

        public bool given_birth { get; set; }

        [Display(Name = "Caso sim, quantas vezes?")]
        [Range(0, 30, ErrorMessage = "Informe um valor")]
        public int? num_children { get; set; }

        [Display(Name = "Há quanto tempo (dias) o paciente apresenta sintomas?")]
        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public int sintomas { get; set; }

        [Display(Name = "Altura (cm)")]
        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public int height { get; set; }

        [Display(Name = "Peso (Quilos)")]
        [Required(ErrorMessage = "O campo {0} é obrigatório")]
        public int weight { get; set; }



        [DataType(DataType.MultilineText)]
        [Display(Name = "Paciente fez uso de medicação prévia? Se sim, por favor transcreva na caixa de comentários")]
        public string comments { get; set; }




        #endregion


        public override string ToString()
        {
            var strRet = $"DemografiaViewmodel|{Id}|{cpf_d1}|{first_name}|{last_name}|{codigocontrole}";
            return strRet;
        }

    }


}
